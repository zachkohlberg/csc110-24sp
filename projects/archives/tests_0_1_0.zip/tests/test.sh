#!/bin/sh

java --class-path tests/bin/ projecttests.Main "$@"
