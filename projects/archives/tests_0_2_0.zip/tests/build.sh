#!/bin/sh

# I could just have this delete the bin folder, but I'm paranoid about including
# potentially destructive commands like rm in shell scripts that I distribute to
# students. Nothing's realistically going to go wrong, but it costs very little
# to err on the side of caution here.
if [ -d tests/bin ]; then
    echo "Delete tests/bin before rebuilding the test program."
    exit 1
fi

# Recreate an empty bin folder to compile the tests to.
mkdir tests/bin

# Compiles all of the necessary test code from src to bin.
javac -Xlint:unchecked --source-path tests/src/ -d tests/bin/ tests/src/projecttests/Main.java

# I use these to generate sample input and output files for the test cases. You
# don't need them for anything, but they're included in the build I distribute,
# so we might as well compile them here.
javac -Xlint:unchecked --source-path tests/src/ -d tests/bin/ tests/src/projecttests/SampleInputs.java
javac -Xlint:unchecked --source-path tests/src/ -d tests/bin/ tests/src/projecttests/SampleOutputs.java
