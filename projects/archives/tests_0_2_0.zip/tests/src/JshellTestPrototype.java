import jdk.jshell.*;
import jdk.jshell.tool.JavaShellToolBuilder;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JshellTestPrototype {
    public static void main(String[] args) throws FileNotFoundException {
        // String prelude = loadInput("Prelude.jsh");
        JavaShellToolBuilder builder = JavaShellToolBuilder.builder();

        ByteArrayInputStream cmdIn = new ByteArrayInputStream(new byte[0]);
        ByteArrayInputStream userIn = new ByteArrayInputStream(input(5).getBytes());

        builder.in(cmdIn, userIn);

        try {
            builder.run("Prelude.jsh", "TestProgram.jsh");
        } catch (Exception e) {
            e.printStackTrace(System.err);
        }
    }

    static String command(int reps, List<String> prelude, List<String> code) {
        /*
        String cmd = "";
        for (String line: prelude) {
            cmd += line + "\n";
        }
        for (int i = 0; i < reps; ++i) {
            for (String line: code) {
                cmd += line + "\n";
            }
            cmd += "nextLine();\n";
        }
        System.out.println(cmd);
        return cmd;
        */
        return "/open Prelude.jsh\n/open TestProgram.jsh\n";
    }

    static String input(int reps) {
        String[] names = new String[] {"Alice", "Bob", "Chuck", "Deb"};
        String input = "";
        for (int i = 0; i < reps; ++i) {
            int birth = 1950 + (int) (Math.random() * 55);
            int current = 2020 + (int) (Math.random() * 10);
            input += names[(int) (Math.random() * names.length)] + "\n";
            input += birth + "\n";
            input += current + "\n";
        }
        return input;
    }

    public static List<String> loadProgram(String path) throws FileNotFoundException {
        List<String> input = new ArrayList<String>();
        try (Scanner sc = new Scanner(new File(path))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().stripTrailing();
                if (!line.isEmpty() && !line.equals("/exit")) {
                    input.add(line);
                }
            }
            return input;
        } catch (FileNotFoundException e) {
            throw e;
        }
    }
}
