/**
 * Main
 *
 * <p>Holds program's main method.
 */
package projecttests;

import projecttests.commands.Commands;
import projecttests.logging.Logger;
import projecttests.util.Command;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static final String COMMAND = "sh tests/test.sh";
    public static final Path LOG_PATH = FileSystems.getDefault().getPath("tests", "logs");
    public static final Path JSH_PATH = FileSystems.getDefault().getPath("tests", "jsh");
    public static final Path STUDENT_PATH = FileSystems.getDefault().getPath("tests", "student");
    public static final Path BIN_PATH = FileSystems.getDefault().getPath("tests", "bin");
    public static final Path DATA_PATH = FileSystems.getDefault().getPath("tests", "data");
    public static final String BACKUP_DIR_NAME = "backup";
    public static final String PASS_FILENAME = "pass.txt";
    public static final String VERSION = "0.2.0";

    public static void main(String[] args) {
        try {
            Logger.start(LOG_PATH);
        } catch (IOException e) {
            System.err.println(
                    """
ERROR: Failed to initialize logger! This is likely a result of running this
program from the wrong location. Make sure you're in your projects folder, not
the tests folder, and that you extracted tests.zip correctly. The file
tests/README.txt includes directions for extracting tests.zip. If you fix both
of these problems or confirm they aren't present and this error still occurs,
then ask for help.
""");
            e.printStackTrace(System.err);
            System.err.println("Also, here's the program's help message:");
            System.err.println(help());
            System.exit(1);
        }
        Logger.info("Program version = " + Main.VERSION);

        if (args.length == 0) {
            error("No command provided! Printing help message:\n" + help(), null);
        }

        String commandId = args[0];
        List<String> argList =
                Arrays.asList(args).stream().skip(1).filter(i -> !i.startsWith("--")).toList();
        List<String> flagList =
                Arrays.asList(args).stream().skip(1).filter(i -> i.startsWith("--")).toList();

        Command<Main> c = Commands.getById(commandId);

        if (c == null) {
            error(commandId + " is not a valid command! Printing help message:\n" + help(), null);
        }

        try {
            c.run(null, flagList, argList);
            end();
        } catch (TestingException e) {
            error(e.getMessage(), e);
        }
    }

    public static String help() {
        return """
Tests and packages your projects.

Usage: {COMMAND} <command>

Commands:
    test        Run tests for one or more projects
    status      Display the status of your projects
    pack        Package projects for submission on Blackboard
    help        Display help messages
    version     Display program's version number

See '{COMMAND} help <command>' for more information on a specific command.
"""
                .replace("{COMMAND}", COMMAND);
    }

    private static void error(String message, Throwable e) {
        System.err.println("ERROR: " + message);
        Logger.error(e, message);
        Logger.stop();
        System.exit(1);
    }

    private static void end() {
        Logger.stop();
        System.exit(0);
    }
}
