/**
 * SampleInputs
 *
 * Spit out some sample inputs for project 1.
 */
package projecttests;

import java.util.stream.Collectors;

import projecttests.projects.*;

public class SampleInputs {
    public static void main(String[] args) {
        System.out.println("1.1:\n");
        System.out.println(Project1Part1.sampleInputs(25).stream().collect(Collectors.joining("\n")));
        System.out.println("\n1.2:\n");
        System.out.println(Project1Part2.sampleInputs(40).stream().collect(Collectors.joining("\n")));
    }
}
