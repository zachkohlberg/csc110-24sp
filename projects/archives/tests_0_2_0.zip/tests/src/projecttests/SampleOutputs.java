/**
 * SampleOutputs
 */
package projecttests;

import java.nio.file.FileSystems;
import java.util.stream.Collectors;

import projecttests.logging.Logger;
import projecttests.projects.Project1Part1;
import projecttests.projects.Project1Part2;
import projecttests.testing.JshellIOTest;

public class SampleOutputs {
    public static void main(String[] args) throws Exception {
        Logger.start(Main.LOG_PATH);

        Project1Part1 p1 = new Project1Part1();
        JshellIOTest test1 = new JshellIOTest(p1);
        System.out.println(test1.generateOutput().stream().collect(Collectors.joining("\n")));

        Project1Part2 p2 = new Project1Part2();
        JshellIOTest test2 = new JshellIOTest(p2);
        System.out.println(test2.generateOutput().stream().collect(Collectors.joining("\n")));
        System.out.println("Done!");
        Logger.stop();
    }
}
