/**
 * TestingException
 *
 * <p>Exceptions I want to pass up to Main. Not a great name, but I'm feeling lazy.
 */
package projecttests;

public class TestingException extends Exception {
    public TestingException(String message) {
        super(message);
    }

    public TestingException(String message, Throwable cause) {
        super(message, cause);
    }
}
