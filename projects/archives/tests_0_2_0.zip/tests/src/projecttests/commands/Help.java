/**
 * Help
 *
 * <p>Displays help message for the program or a specific command.
 */
package projecttests.commands;

import projecttests.*;
import projecttests.util.Command;

import java.util.List;

public class Help implements Command<Main> {
    @Override
    public void run(Main context, List<String> flags, List<String> args) throws TestingException {
        if (args.size() > 1) {
            throw new TestingException(id() + " expects zero or one arguments");
        }

        if (args.size() == 1) {
            Command c = Commands.getById(args.get(0));
            if (c == null) {
                throw new TestingException(args.get(0) + " isn't a command");
            }

            System.out.println(c.help());
        } else {
            System.out.println(Main.help());
        }
    }

    @Override
    public String id() {
        return "help";
    }

    @Override
    public String help() {
        return """
Displays a help message for the program or a specific command.

USAGE:  {COMMAND} help
        {COMMAND} help <command>

Examples:

{COMMAND} help
{COMMAND} help test
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
