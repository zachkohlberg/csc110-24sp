/**
 * Pack
 *
 * <p>Packages one or more projects for submission.
 */
package projecttests.commands;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.projects.Projects;
import projecttests.util.Command;
import projecttests.util.FileIO;
import projecttests.util.Project;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Pack implements Command<Main> {
    @Override
    public void run(Main context, List<String> flags, List<String> args) throws TestingException {
        if (args.size() != 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        Logger.info("Pack command");

        boolean includeNopass = flags.contains("--include-nopass");

        ArrayList<String> command = new ArrayList<>();
        command.add("zip");
        command.add("guided_project_submission.zip");

        List<Project> include =
                Projects.all().stream().filter(i -> check(i, includeNopass)).toList();

        if (include.isEmpty()) {
            Logger.info("No projects included, did not create zip.").print();
            return;
        }

        include.stream()
                .forEach(
                        p ->
                                command.addAll(
                                        p.projectFilePaths().stream()
                                                .map(i -> i.normalize().toString())
                                                .toList()));

        try {
            Logger.info("Zipping project files.");
            ProcessBuilder builder = new ProcessBuilder(command);

            Process zip = builder.start();
            if (zip.waitFor(30, TimeUnit.SECONDS)) {
                if (zip.exitValue() == 0) {
                    Logger.info(
                                    "Finished packing test files. Upload"
                                            + " guided_project_submission.zip to Blackboard AFTER"
                                            + " checking it to confirm that all required files are"
                                            + " included.")
                            .print();
                } else {
                    throw new TestingException("Zip process exited with an error.");
                }
            } else {
                throw new TestingException("Zip process timed out while trying to pack project.");
            }
        } catch (Exception e) {
            throw new TestingException(
                    "Unexpected exception while trying to zip project files.", e);
        }
    }

    boolean check(Project project, boolean includeNopass) {
        Logger.info("Checking project " + project.id()).print();
        String name = "Project " + project.id();

        if (!project.checkProjectFiles()) {
            Logger.info(
                            name
                                    + " will be skipped because it is missing files or a file is"
                                    + " named incorrectly.")
                    .print();
            return false;
        } else {
            Logger.info(name + "'s files were located successfully.").print();
        }

        List<String> passData = FileIO.loadOrElse(project.passFilePath(), null);
        if (passData == null || passData.size() == 0 || !passData.get(0).equals("PASS")) {
            if (includeNopass) {
                Logger.info(
                                "WARNING: "
                                        + name
                                        + " hasn't passed its tests, but you've chosen to include"
                                        + " nonpassing projects.")
                        .print();
            } else {
                Logger.info(
                                name
                                        + " will be skipped because it hasn't passed its tests. You"
                                        + " can include it anyway by rerunning this command with"
                                        + " the --include-nopass flag.")
                        .print();
                return false;
            }
        } else {
            Logger.info(name + " appears to have passed its tests.");
        }

        Logger.info(name + " will be included in the zip.").print();

        return true;
    }

    @Override
    public String id() {
        return "pack";
    }

    @Override
    public String help() {
        return """
Packages all projects that have previously passed their tests for upload to
Blackboard.

USAGE: {COMMAND} pack [FLAG]...

Flags:
    --include-nopass        don't skip projects that haven't passed their tests
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
