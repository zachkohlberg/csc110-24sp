/**
 * Check
 *
 * <p>Checks the directory structure and previous test results for every project.
 */
package projecttests.commands;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.projects.Projects;
import projecttests.util.Command;
import projecttests.util.FileIO;
import projecttests.util.Project;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

public class Status implements Command<Main> {
    @Override
    public void run(Main context, List<String> flags, List<String> args) throws TestingException {
        if (args.size() != 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        for (Project project : Projects.all()) {
            List<String> studentCode = FileIO.loadOrElse(project.programFilePath(), null),
                    studentCodeBackup = FileIO.loadOrElse(project.programFileBackupPath(), null),
                    passData = FileIO.loadOrElse(project.passFilePath(), null);

            StringBuilder builder = new StringBuilder();

            builder.append("Project " + project.id() + "\n");

            builder.append("\n");

            builder.append("Required project files:\n");
            for (Path p: project.projectFilePaths()) {
                String found;
                if (FileIO.loadOrElse(p, null) == null) {
                    found = "MISSING";
                } else if (!FileIO.exactRelativePathExists(p)) {
                    found = "MISCAPITALIZED";
                } else {
                    found = "FOUND";
                }
                builder.append("\t(FILE " + found + ") " + p.normalize() + "\n");
            }

            builder.append("\n");

            builder.append("Last recorded test:\n");
            if (passData != null && passData.size() >= 2) {
                String passing = passData.get(0);
                String timestamp = passData.get(1);
                builder.append("\tResult: " + passing + "\n");
                builder.append("\tTested: " + timestamp + "\n");
                if (studentCodeBackup != null) {
                    boolean changed = studentCodeBackup.size() != studentCode.size();
                    if (!changed) {
                        for (int i = 0; i < studentCode.size(); ++i) {
                            if (!studentCode.get(i).equals(studentCodeBackup.get(i))) {
                                changed = true;
                                break;
                            }
                        }
                    }
                    builder.append("\tModified since last test: " + (changed ? "YES" : "NO") + "\n");
                } else {
                    builder.append("\tBackup from last test is missing. The test command normally saves an\n");
                    builder.append("\tunmodified copy of your program at the end of a test. This allows the\n");
                    builder.append("\tstatus command to check for changes.\n");
                }
            } else {
                builder.append("\tNo record found\n");
            }

            Logger.info(builder.toString()).print();
        }
    }

    @Override
    public String id() {
        return "status";
    }

    @Override
    public String help() {
        return """
Displays the following information about your projects:
- whether each project's directory was found
- for all projects found, whether the expected files were found
- for all projects found, whether the project has previously passed its tests

USAGE: {COMMAND} status
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
