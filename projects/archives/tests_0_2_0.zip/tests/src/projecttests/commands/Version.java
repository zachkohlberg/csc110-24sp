/**
 * Version
 *
 * <p>Displays program version
 */
package projecttests.commands;

import projecttests.*;
import projecttests.util.Command;

import java.util.List;

public class Version implements Command<Main> {
    @Override
    public void run(Main context, List<String> flags, List<String> args) throws TestingException {
        if (args.size() > 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        System.out.println(Main.VERSION);
    }

    @Override
    public String id() {
        return "version";
    }

    @Override
    public String help() {
        return """
Displays the program version.

USAGE:  {COMMAND} version
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
