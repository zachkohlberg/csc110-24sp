/**
 * Logger
 *
 * <p>Handles logging all program activity.
 */
package projecttests.logging;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {
    private static PrintWriter writerA, writerB;
    private static Object lock = new Object();

    public static void start(Path path) throws IOException {
        var timestamp =
                LocalDateTime.now()
                        .format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                        .replaceAll(":", "_");
        try {
            Files.createDirectories(path);
            writerB = new PrintWriter(path.resolve("log_" + timestamp + ".txt").toFile());
            writerA = new PrintWriter(path.resolve("log_last.txt").toFile());
            info("LOG START");
        } catch (IOException e) {
            throw e;
        }
    }

    public static LogMessage info(Object obj) {
        return log("INFO", obj.toString(), new Object[0], null);
    }

    public static LogMessage info(String message, Object... args) {
        return log("INFO", message, args, null);
    }

    public static LogMessage warn(Object obj) {
        return log("WARN", obj.toString(), new Object[0], null);
    }

    public static LogMessage warn(String message, Object... args) {
        return log("WARN", message, args, null);
    }

    public static LogMessage error(Object obj) {
        return log("ERROR", obj.toString(), new Object[0], null);
    }

    public static LogMessage error(Throwable e, Object obj) {
        return log("ERROR", obj.toString(), new Object[0], null);
    }

    public static LogMessage error(String message, Object... args) {
        return log("ERROR", message, args, null);
    }

    public static LogMessage error(Throwable e, String message, Object... args) {
        return log("ERROR", message, args, e);
    }

    private static LogMessage log(String prefix, String message, Object[] args, Throwable e) {
        message = message.formatted(args);
        var timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        synchronized (lock) {
            writerA.printf("[%s][%s]\n%s\n", timestamp, prefix, message);
            writerB.printf("[%s][%s]\n%s\n", timestamp, prefix, message);
            if (e != null) {
                writerA.printf("[%s][STACK_TRACE]\n", timestamp);
                writerB.printf("[%s][STACK_TRACE]\n", timestamp);
                e.printStackTrace(writerA);
                e.printStackTrace(writerB);
            }
        }

        return new LogMessage(System.out, message);
    }

    public static class LogMessage {
        private PrintStream out;
        private String message;

        LogMessage(PrintStream out, String message) {
            this.out = out;
            this.message = message;
        }

        public void print() {
            out.println(message);
        }
    }

    public static void stop() {
        info("LOG END");
        writerA.flush();
        writerB.flush();
        writerA.close();
        writerB.close();
    }
}
