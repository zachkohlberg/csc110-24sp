/**
 * Project1Part1
 *
 * <p>Tests for project 1 part 1.
 */
package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JshellIOTest;
import projecttests.testing.TestResult;
import projecttests.util.Project;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

public class Project1Part1 implements Project {
    @Override
    public String id() {
        return "1.1";
    }

    @Override
    public String programName() {
        return "CharacterSheet1.jsh";
    }

    @Override
    public Path path() {
        return FileSystems.getDefault().getPath("project1", "part1");
    }

    @Override
    public TestResult test() throws TestingException {
        JshellIOTest test = new JshellIOTest(this);
        return test.run();
    }

    public static List<String> sampleInputs(int size) {
        String[] inputs = new String[size];
        for (int i = 0; i < size; ++i) {
            inputs[i] =
                    String.format(
                            "%s|%s|%s|%s|%s|%s",
                            Project1Inputs.randomBeefAndDairyActor(),
                            Project1Inputs.randomBeefAndDairyCharacter(),
                            Project1Inputs.randomLevel(),
                            Project1Inputs.randomAbilityScore(),
                            Project1Inputs.randomAbilityScore(),
                            Project1Inputs.randomAbilityScore());
        }
        return Arrays.asList(inputs);
    }
}
