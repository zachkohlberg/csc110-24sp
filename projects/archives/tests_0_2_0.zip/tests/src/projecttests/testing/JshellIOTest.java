/**
 * JshellIOTest
 *
 * <p>Tests a Jshell program's I/O with multiple test cases.
 */
package projecttests.testing;

import jdk.jshell.tool.JavaShellToolBuilder;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.util.Project;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class JshellIOTest {
    private int timeout = 300, nThreads = 50;
    private Project project;
    private Path modifiedStudentCodePath,
            inputPath,
            expectedOutputPath,
            testSetupJshPath,
            quitJshPath;

    public JshellIOTest(Project project) {
        this.project = project;
        modifiedStudentCodePath = Main.STUDENT_PATH.resolve(project.programFilePath());
        inputPath = Main.DATA_PATH.resolve(project.path()).resolve("jshell_input.txt");
        expectedOutputPath =
                Main.DATA_PATH.resolve(project.path()).resolve("jshell_expected_output.txt");
        testSetupJshPath = Main.JSH_PATH.resolve("JshellTestSetup.jsh");
        quitJshPath = Main.JSH_PATH.resolve("Quit.jsh");
    }

    public TestResult run() throws TestingException {
        Instant runStartTime = Instant.now();

        Logger.info("Loading resources for Jshell IO Test.");

        List<String> studentCode = loadResource(project.programFilePath()),
                input = loadResource(inputPath),
                expectedOutput = loadResource(expectedOutputPath);

        if (!project.checkProjectFiles()) {
            throw new TestingException(
                    "Your program's path appears to differ in case from the expected path. Make"
                            + " sure you named all files and folders in your projects folder as"
                            + " directed!");
        }

        List<String> cleanStudentCode = cleanProgram(studentCode);

        Logger.info(
                "Student code after trim/filter:\n%s",
                cleanStudentCode.stream().collect(Collectors.joining("\n")));

        createModifiedProgram(cleanStudentCode, modifiedStudentCodePath);

        ExecutorService threadPool = Executors.newFixedThreadPool(nThreads);
        ArrayList<Task> tasks = new ArrayList<Task>();
        for (int i = 0; i < input.size(); ++i) {
            tasks.add(new Task("jshell-io", i + 1, input.get(i), expectedOutput.get(i)));
        }
        System.out.println("Running " + input.size() + " Jshell IO tests. Progress:");
        System.out.println("_".repeat(input.size()));
        List<Future<TestCaseResult>> futures;
        try {
            futures = threadPool.invokeAll(tasks, timeout, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new TestingException("Testing interrupted!", e);
        }
        System.out.println();

        List<TestCaseResult> results =
                futures.stream()
                        .filter(i -> i.state() == Future.State.SUCCESS)
                        .map(Future::resultNow)
                        .toList();
        int count = tasks.size();
        int passed = (int) results.stream().filter(i -> i.result).count();
        int failed = (int) results.stream().filter(i -> !i.result).count();
        int error = (int) futures.stream().filter(i -> i.state() == Future.State.FAILED).count();
        int timeout =
                (int) futures.stream().filter(i -> i.state() == Future.State.CANCELLED).count();

        Instant runEndTime = Instant.now();
        long runDuration = runStartTime.until(runEndTime, ChronoUnit.MILLIS);
        Logger.info("Tests finished after %d.%03d seconds.", runDuration / 1000, runDuration % 1000)
                .print();

        threadPool.close();

        TestResult overallResult =
                new TestResult(results, cleanStudentCode, count, passed, failed, error, timeout);

        Logger.info("Saving backup of student program and saving overall result");

        try {
            Files.createDirectories(project.programFileBackupPath().getParent());
            Files.write(
                    project.programFileBackupPath(),
                    studentCode,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            Logger.error(e, "IOException while saving backup of student program").print();
        }

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

        try {
            Files.createDirectories(project.passFilePath().getParent());
            Files.write(
                    project.passFilePath(),
                    List.of(overallResult.overallPass ? "PASS" : "FAIL", timestamp),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            Logger.error(e, "IOException while recording test result").print();
        }

        return overallResult;
    }

    public List<String> generateOutput() throws TestingException {
        List<String> studentCode = loadResource(project.programFilePath()),
                input = loadResource(inputPath);

        studentCode = cleanProgram(studentCode);

        createModifiedProgram(studentCode, modifiedStudentCodePath);

        ExecutorService threadPool = Executors.newFixedThreadPool(nThreads);
        ArrayList<Task> tasks = new ArrayList<Task>();
        for (int i = 0; i < input.size(); ++i) {
            tasks.add(new Task("jshell-io", i + 1, input.get(i), ""));
        }
        System.out.println("Running " + input.size() + " Jshell IO tests. Progress:");
        System.out.println("_".repeat(input.size()));

        List<Future<TestCaseResult>> futures;
        try {
            futures = threadPool.invokeAll(tasks, timeout, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new TestingException("Testing interrupted!", e);
        }

        System.out.println();
        System.out.println("Finished generating test output.");

        List<TestCaseResult> results =
                futures.stream()
                        .filter(i -> i.state() == Future.State.SUCCESS)
                        .map(Future::resultNow)
                        .toList();
        results.stream().forEach(i -> Logger.info("Test Case:\n%s", i.fullInfo()));

        System.out.println("count: " + tasks.size());
        System.out.println("pass: " + results.stream().filter(i -> i.result).count());
        System.out.println("fail: " + results.stream().filter(i -> !i.result).count());
        System.out.println(
                "error: " + futures.stream().filter(i -> i.state() == Future.State.FAILED).count());
        System.out.println(
                "timeout: "
                        + futures.stream()
                                .filter(i -> i.state() == Future.State.CANCELLED)
                                .count());

        List<String> studentOutput =
                results.stream()
                        .sorted(
                                new Comparator<TestCaseResult>() {
                                    public int compare(TestCaseResult r1, TestCaseResult r2) {
                                        return Integer.parseInt(r1.id) - Integer.parseInt(r2.id);
                                    }
                                })
                        .map(
                                i ->
                                        i.studentOutput.stream()
                                                .map(j -> j.output)
                                                .filter(j -> !j.startsWith("##"))
                                                .collect(Collectors.joining("|")))
                        .toList();

        threadPool.close();

        return studentOutput;
    }

    List<String> cleanProgram(List<String> studentCode) {
        return studentCode.stream()
                .map(i -> i.trim())
                .filter(i -> !(i.startsWith("//") || i.startsWith("/exit") || i.isBlank()))
                .collect(Collectors.toList());
    }

    List<String> cleanOutput(List<String> output) {
        return output.stream()
                .map(i -> i.trim())
                .filter(i -> !(i == null || i.isBlank()))
                .collect(Collectors.toList());
    }

    void createModifiedProgram(List<String> program, Path path) throws TestingException {
        List<String> modifiedProgram = modifyProgram(program);

        Logger.info(
                "Modified program for testing:\n%s",
                modifiedProgram.stream().collect(Collectors.joining("\n")));

        try {
            Files.createDirectories(path.getParent());
            Files.write(
                    path,
                    modifiedProgram,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            Logger.error(
                    e,
                    "IOException while writing modified student program to %s for Jshell IO test.",
                    path);
            throw new TestingException("Failed to save test version of student code.", e);
        }
    }

    List<String> modifyProgram(List<String> program) {
        List<String> modifiedProgram = new ArrayList<String>();
        modifiedProgram.add(
                "// This was generated by the test program and will be overwritten every time");
        modifiedProgram.add(
                "// you test your code. Don't modify this program! You will lose all of that");
        modifiedProgram.add("// work when you try to test it.");
        modifiedProgram.addAll(program);
        return modifiedProgram;
    }

    List<String> loadResource(Path path) throws TestingException {
        try (var stream = Files.lines(path)) {
            List<String> list = stream.collect(Collectors.toList());
            Logger.info(
                    "Read lines from %s:\n%s",
                    path, list.stream().collect(Collectors.joining("\n")));
            return list;
        } catch (IOException e) {
            Logger.error(
                    e, "IOException while loading resource at " + path + " for Jshell IO test.");
            throw new TestingException(
                    "Failed to load resource at " + path + " for Jshell IO test.", e);
        }
    }

    class Task implements Callable<TestCaseResult> {
        private String label, id, input, expectedOutput;
        private List<String> output, errors;

        public Task(String label, int id, String input, String expectedOutput) {
            this.label = label;
            this.id = "" + id;
            this.input = input;
            this.expectedOutput = expectedOutput;
        }

        @Override
        public TestCaseResult call() throws Exception {
            runJshell();
            System.out.print("#");
            return TestCaseResult.compileTestResult(
                    label,
                    id,
                    Arrays.asList(input.split("\\|")),
                    errors,
                    output,
                    cleanOutput(Arrays.asList(expectedOutput.split("\\|"))));
        }

        /*
                Logger.error(
                        e,
                        "Exception occurred while running Jshell IO Test; id=%s; input=%s;"
                                + " expectedOutput=%s",
                        id,
                        input,
                        expectedOutput);
                feedback.add("An exception occurred while trying to run this test case.");
                error = true;
        */

        void runJshell() throws Exception {
            try (ByteArrayOutputStream bufferIgnore = new ByteArrayOutputStream();
                    ByteArrayOutputStream bufferOut = new ByteArrayOutputStream();
                    ByteArrayOutputStream bufferErr = new ByteArrayOutputStream();
                    ByteArrayInputStream cmdIn = new ByteArrayInputStream(new byte[0]);
                    ByteArrayInputStream userIn =
                            new ByteArrayInputStream(
                                    Arrays.asList(input.split("\\|")).stream()
                                            .collect(Collectors.joining("\n"))
                                            .getBytes());
                    PrintStream printIgnore = new PrintStream(bufferIgnore);
                    PrintStream printOut = new PrintStream(bufferOut);
                    PrintStream printErr = new PrintStream(bufferErr)) {
                JavaShellToolBuilder.builder()
                        .in(cmdIn, userIn)
                        .out(printIgnore, printIgnore, printOut)
                        .err(printErr)
                        .run(
                                testSetupJshPath.toString(),
                                modifiedStudentCodePath.toString(),
                                quitJshPath.toString());

                output = cleanOutput(Arrays.asList(bufferOut.toString().split("\n")));
                errors =
                        Arrays.asList(bufferErr.toString().split("\n")).stream()
                                .filter(i -> i != null && !i.isBlank())
                                .toList();
            }
        }
    }
}
