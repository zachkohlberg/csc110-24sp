/**
 * LineStatus
 *
 * <p>Represents each possible status for a line of output.
 */
package projecttests.testing;

public enum LineStatus {
    MATCH,
    NO_MATCH,
    ERROR,
}
