/**
 * OutputLine
 *
 * <p>Represents a single line of output and whether it matched with another line.
 */
package projecttests.testing;

public class OutputLine {
    public String output;
    public LineStatus status;

    public OutputLine(String output, LineStatus status) {
        this.output = output;
        this.status = status;
    }

    public String toString() {
        return "%-20s%s".formatted(status, output);
    }
}
