/**
 * TestResult
 *
 * <p>Holds all relevant information about how a finished test case.
 */
package projecttests.testing;

import projecttests.util.Strings;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TestCaseResult {
    public String label, id;
    public List<String> programInput, errors;
    public List<OutputLine> studentOutput, expectedOutput;
    public ArrayList<String> feedback;
    public boolean result;

    private TestCaseResult(
            String label,
            String id,
            List<String> programInput,
            List<String> errors,
            List<OutputLine> studentOutput,
            List<OutputLine> expectedOutput,
            boolean result) {
        this.label = label;
        this.id = id;
        this.programInput = programInput;
        this.errors = errors;
        this.studentOutput = studentOutput;
        this.expectedOutput = expectedOutput;
        this.feedback = new ArrayList<String>();
        this.result = result;
    }

    public String summaryString() {
        return "{label} {id}: {result} ({correctLines}/{totalLines} expected lines match)"
                .replace("{label}", label)
                .replace("{id}", id)
                .replace("{result}", result ? "PASS" : "FAIL")
                .replace(
                        "{correctLines}",
                        ""
                                + expectedOutput.stream()
                                        .filter(i -> i.status == LineStatus.MATCH)
                                        .count())
                .replace("{totalLines}", "" + expectedOutput.size());
    }

    public String headerString() {
        return "%sLabel: %s\nID: %s\nResult: %s\n"
                .formatted(
                        Strings.header("Test Result", "\n\n"), label, id, result ? "PASS" : "FAIL");
    }

    private String listString(String header, List<String> list, String ifEmpty) {
        return Strings.header(header, "\n\n\n")
                + (list.isEmpty() ? ifEmpty : list.stream().collect(Collectors.joining("\n")))
                + "\n";
    }

    private String listString(String header, List<String> list) {
        return listString(header, list, "");
    }

    public String programInputString() {
        return listString("Program Input", programInput);
    }

    public String errorsString() {
        return listString("Errors", errors);
    }

    public String studentProgramOutputString() {
        return listString(
                "Student Program Output", studentOutput.stream().map(i -> i.toString()).toList());
    }

    public String studentProgramNoMatchOutputString() {
        return listString(
                "Student Program Output",
                studentOutput.stream()
                        .filter(i -> i.status != LineStatus.MATCH)
                        .map(i -> i.toString())
                        .toList());
    }

    public String expectedProgramOutputString() {
        return listString(
                "Expected Program Output", expectedOutput.stream().map(i -> i.toString()).toList());
    }

    public String expectedProgramNoMatchOutputString() {
        return listString(
                "Expected Program Output",
                expectedOutput.stream()
                        .filter(i -> i.status != LineStatus.MATCH)
                        .map(i -> i.toString())
                        .toList());
    }

    public String additionalFeedbackString() {
        return listString("Additional Feedback", feedback, "none");
    }

    public String fullInfo() {
        return programInputString()
                + "\n"
                + studentProgramOutputString()
                + "\n"
                + expectedProgramOutputString()
                + "\n"
                + errorsString()
                + "\n"
                + additionalFeedbackString();
    }

    public static TestCaseResult compileTestResult(
            String label,
            String id,
            List<String> programInput,
            List<String> errors,
            List<String> studentOutput,
            List<String> expectedOutput) {
        List<OutputLine> studentOutputChecked = new ArrayList<OutputLine>(),
                expectedOutputChecked = new ArrayList<OutputLine>();

        for (String expected : expectedOutput) {
            if (studentOutput.stream()
                    .skip(studentOutputChecked.size())
                    .anyMatch(i -> i.equals(expected))) {
                studentOutputChecked.addAll(
                        studentOutput.stream()
                                .skip(studentOutputChecked.size())
                                .takeWhile(i -> !i.equals(expected))
                                .map(i -> new OutputLine(i, LineStatus.NO_MATCH))
                                .collect(Collectors.toList()));
                expectedOutputChecked.add(new OutputLine(expected, LineStatus.MATCH));
                studentOutputChecked.add(new OutputLine(expected, LineStatus.MATCH));
            } else {
                expectedOutputChecked.add(new OutputLine(expected, LineStatus.ERROR));
            }
        }
        studentOutput.stream()
                .skip(studentOutputChecked.size())
                .forEach(i -> studentOutputChecked.add(new OutputLine(i, LineStatus.NO_MATCH)));

        boolean result = expectedOutputChecked.stream().allMatch(i -> i.status == LineStatus.MATCH);

        return new TestCaseResult(
                label,
                id,
                programInput,
                errors,
                studentOutputChecked,
                expectedOutputChecked,
                result);
    }
}
