/**
 * TestResult
 *
 * Holds the result of a test involving multiple test cases.
 */
package projecttests.testing;

import java.util.List;
import java.util.stream.Collectors;

public class TestResult {
    public final List<TestCaseResult> results;
    public final List<String> studentCode;
    public final int count, passed, failed, error, timeout;
    public final boolean overallPass;

    public TestResult(List<TestCaseResult> results, List<String> studentCode, int count, int passed, int failed, int error, int timeout) {
        this.results = results;
        this.studentCode = studentCode;
        this.count = count;
        this.passed = passed;
        this.failed = failed;
        this.error = error;
        this.timeout = timeout;
        this.overallPass = count == passed;
    }

    public String studentCodeString() {
        return """
################
# Student Code #
################

{studentCode}
"""
                .replace("{studentCode}", studentCode.stream().collect(Collectors.joining("\n")));
    }

}
