/**
 * List
 *
 * <p>Command to list all test results.
 */
package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;

import java.util.stream.Collectors;

public class List implements Command<ResultsBrowser> {
    @Override
    public void run(
            ResultsBrowser context, java.util.List<String> flags, java.util.List<String> args)
            throws TestingException {
        if (args.size() > 1) {
            throw new TestingException(id() + " expects zero or one arguments");
        }

        String filter = "all";
        if (args.size() > 0) {
            filter = args.get(0);
        }

        switch (filter) {
            case "pass":
                System.out.println(
                        context.list().stream()
                                .filter(i -> i.result)
                                .map(i -> i.summaryString())
                                .collect(Collectors.joining("\n")));
                break;
            case "fail":
                System.out.println(
                        context.list().stream()
                                .filter(i -> !i.result)
                                .map(i -> i.summaryString())
                                .collect(Collectors.joining("\n")));
                break;
            case "all":
                System.out.println(
                        context.list().stream()
                                .map(i -> i.summaryString())
                                .collect(Collectors.joining("\n")));
                break;
            default:
                throw new TestingException(filter + " is not a valid filter");
        }
    }

    @Override
    public String id() {
        return "list";
    }

    @Override
    public String help() {
        return """
Displays a list of each test case and its results.

USAGE: list [FILTER]

Filters:
    pass        show only passing test cases
    fail        show only failing test cases
    all         show all test cases (default)
""";
    }
}
