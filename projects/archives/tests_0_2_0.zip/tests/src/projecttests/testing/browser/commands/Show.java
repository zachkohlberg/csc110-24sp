/**
 * Show
 *
 * <p>View information about a specific test case.
 */
package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.TestCaseResult;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;

import java.util.List;
import java.util.stream.Collectors;

public class Show implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, List<String> flags, List<String> args)
            throws TestingException {
        if (args.size() == 0) {
            throw new TestingException(id() + " expects one or more arguments");
        }

        String id = args.get(0);
        TestCaseResult result = context.getById(id);
        if (result == null) {
            throw new TestingException(id + " is not a valid id number.");
        }

        List<String> invalid = args.stream().skip(1).filter(i -> getInfo(result, i) == null).toList();
        if (!invalid.isEmpty()) {
            throw new TestingException("ERROR: the option(s) " + invalid.stream().collect(Collectors.joining(", ")) + " are invalid.");
        }

        System.out.println(result.headerString());
        if (args.size() > 1) {
            System.out.println(args.stream().skip(1).map(i -> getInfo(result, i)).collect(Collectors.joining("\n")));
        } else {
            System.out.println(result.fullInfo());
        }
    }

    private String getInfo(TestCaseResult result, String info) {
        switch (info) {
            case "in":
            case "input":
                return result.programInputString();
            case "st-out":
                return result.studentProgramOutputString();
            case "ex-out":
                return result.expectedProgramOutputString();
            case "out":
            case "output":
                return result.studentProgramOutputString()
                        + "\n"
                        + result.expectedProgramOutputString();
            case "out-err":
                return result.studentProgramNoMatchOutputString()
                        + "\n"
                        + result.expectedProgramNoMatchOutputString();
            case "io":
                return result.programInputString()
                        + "\n"
                        + result.studentProgramOutputString()
                        + "\n"
                        + result.expectedProgramOutputString();
            case "err":
            case "error":
                return result.errorsString();
            case "feedback":
                return result.additionalFeedbackString();
            case "full":
                return result.fullInfo();
            default:
                return null;
        }
    }

    @Override
    public String id() {
        return "show";
    }

    @Override
    public String help() {
        return """
Shows information about a specific test case. If no INFO is specified, then full
information about the test case will be shown.

USAGE: show ID [INFO]...

ID is the number after the test label.

INFO Options:
    in, input       the input given to your program
    st-out          your program's output
    ex-out          the expected output
    out, output     both your program's output and the expected output
    out-err         only output lines listed as NO MATCH or ERROR
    io              both the input and output
    err, error      error messages
    feedback        additional feedback messages
    full            all available information (default)

Examples:

show 3
show 11 out
show 5 in st-out
show 5 error
show 1 full
""";
    }
}
