/**
 * Summary
 *
 * Display summary of all test results
 */
package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;

public class Summary implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, java.util.List<String> flags, java.util.List<String> args) throws TestingException {
        if (args.size() > 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        System.out.println(context.summary());
    }

    @Override
    public String id() {
        return "summary";
    }

    @Override
    public String help() {
        return """
Displays a summary of all test results

USAGE: summary
""";
    }
}
