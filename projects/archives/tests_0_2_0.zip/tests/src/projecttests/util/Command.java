/**
 * Command
 *
 * <p>Defines interface for program's commands.
 */
package projecttests.util;

import projecttests.TestingException;

import java.util.List;

public interface Command<T> extends HasId {
    void run(T context, List<String> flags, List<String> args) throws TestingException;

    String help();
}
