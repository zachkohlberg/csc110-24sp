/**
 * FileIO
 *
 * <p>Common operations inloving paths and files.
 */
package projecttests.util;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

import projecttests.logging.Logger;

public final class FileIO {
    public static boolean exactRelativePathExists(Path path) {
        Path workingDir = FileSystems.getDefault().getPath(".").toAbsolutePath().normalize();
        try {
            Path realPath = workingDir.relativize(path.toRealPath());
            return path.normalize().toString().equals(realPath.toString());
        } catch (IOException e) {
            return false;
        }
    }

    public static List<String> loadOrElse(Path path, List<String> orElse) {
        try (var stream = Files.lines(path)) {
            List<String> list = stream.collect(Collectors.toList());
            Logger.info(
                    "Read lines from %s:\n%s",
                    path, list.stream().collect(Collectors.joining("\n")));
            return list;
        } catch (IOException e) {
            Logger.error(e, "IOException while loading file at " + path);
            return orElse;
        }
    }
}
