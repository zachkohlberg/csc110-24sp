/**
 * Project
 *
 * <p>Defines interface for individual or groups of projects.
 */
package projecttests.util;

import projecttests.Main;
import projecttests.TestingException;
import projecttests.testing.TestResult;

import java.nio.file.Path;
import java.util.List;

public interface Project extends HasId {
    String programName();

    Path path();

    default Path programFilePath() {
        return path().resolve(programName());
    }

    default List<Path> projectFilePaths() {
        return List.of(path().resolve(programName()));
    }

    default boolean checkProjectFiles() {
        for (Path p : projectFilePaths()) {
            if (!FileIO.exactRelativePathExists(p)) {
                return false;
            }
        }

        return true;
    }

    default Path passFilePath() {
        return Main.STUDENT_PATH.resolve(path()).resolve(Main.PASS_FILENAME);
    }

    default Path programFileBackupPath() {
        return Main.STUDENT_PATH
                .resolve(path())
                .resolve(Main.BACKUP_DIR_NAME)
                .resolve(programName());
    }

    TestResult test() throws TestingException;
}
