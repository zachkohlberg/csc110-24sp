/**
 * Strings
 *
 * Helper methods for strings.
 */
package projecttests.util;

public final class Strings {
    public static String header(String text, String suffix) {
        String border = "#".repeat(text.length() + 4);
        return border + "\n" + text + "\n" + border + suffix;
    }
}
