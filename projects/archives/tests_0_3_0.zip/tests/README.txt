These files should be extracted into your projects/tests folder. If extracted
properly, you will see the file "test.sh" directly inside projects/tests. If you
instead see another folder named "tests", then you've accidentally extracted
everything into projects/tests/tests.

If you're using a bash terminal or bash emulator, then you should be able to
extract everything using the unzip command:
- save this zip archive (tests.zip) to your normal Downloads folder
- cd into your projects/tests folder
- run the command 'unzip ~/Downloads/tests.zip'
