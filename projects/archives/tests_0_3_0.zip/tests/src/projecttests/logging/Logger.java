package projecttests.logging;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Handles logging all program activity. */
public class Logger {
    private static PrintWriter writerA, writerB;
    private static Object lock = new Object();
    private static boolean logging = false;

    public static boolean logging() {
        return logging;
    }

    public static void start(Path path) throws IOException {
        if (logging) {
            throw new IllegalStateException("Can't start Logger because it's already running!");
        }

        var timestamp =
                LocalDateTime.now()
                        .format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                        .replaceAll(":", "_");
        try {
            Files.createDirectories(path);
            writerB = new PrintWriter(path.resolve("log_" + timestamp + ".txt").toFile());
            writerA = new PrintWriter(path.resolve("log_last.txt").toFile());
            logging = true;
            info("LOG START");
        } catch (IOException e) {
            throw e;
        }
    }

    public static LogMessage info(Object obj) {
        return log("INFO", obj.toString(), new Object[0], null);
    }

    public static LogMessage infoFormat(String message, Object... args) {
        return log("INFO", message, args, null);
    }

    public static LogMessage warn(Object obj) {
        return log("WARN", obj.toString(), new Object[0], null);
    }

    public static LogMessage warnFormat(String message, Object... args) {
        return log("WARN", message, args, null);
    }

    public static LogMessage error(Object obj) {
        return log("ERROR", obj.toString(), new Object[0], null);
    }

    public static LogMessage error(Throwable e, Object obj) {
        return log("ERROR", obj.toString(), new Object[0], e);
    }

    public static LogMessage errorFormat(String message, Object... args) {
        return log("ERROR", message, args, null);
    }

    public static LogMessage errorFormat(Throwable e, String message, Object... args) {
        return log("ERROR", message, args, e);
    }

    private static LogMessage log(String prefix, String message, Object[] args, Throwable e) {
        message = message.formatted(args);
        var timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        synchronized (lock) {
            if (logging) {
                writerA.printf("[%s][%s]\n%s\n", timestamp, prefix, message);
                writerB.printf("[%s][%s]\n%s\n", timestamp, prefix, message);
                if (e != null) {
                    writerA.printf("[%s][STACK_TRACE]\n", timestamp);
                    writerB.printf("[%s][STACK_TRACE]\n", timestamp);
                    e.printStackTrace(writerA);
                    e.printStackTrace(writerB);
                }
            }
        }

        return new LogMessage(System.out, message);
    }

    public static class LogMessage {
        private PrintStream out;
        private String message;

        LogMessage(PrintStream out, String message) {
            this.out = out;
            this.message = message;
        }

        public void print() {
            out.println(message);
        }
    }

    public static void stop() {
        if (!logging) {
            throw new IllegalStateException("Can't stop Logger because it's not running!");
        }

        logging = false;

        info("LOG END");

        writerA.flush();
        writerB.flush();
        writerA.close();
        writerB.close();
    }
}
