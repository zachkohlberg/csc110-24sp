package projecttests.projects;

import projecttests.util.HasId;
import projecttests.util.Project;

import java.util.List;

/** Contains helper methods for projects. */
public final class Projects {
    static List<Project> all =
            List.of(
                    new Project[] {
                        new Project1Part1(),
                        new Project1Part2(),
                        new Project2Part1(),
                        new Project2Part2()
                    });

    public static List<Project> all() {
        return all;
    }

    public static Project getById(String id) {
        return HasId.getById(id, all);
    }

    public static boolean isProject(String id) {
        return getById(id) != null;
    }
}
