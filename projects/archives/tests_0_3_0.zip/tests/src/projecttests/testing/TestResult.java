package projecttests.testing;

import projecttests.util.Strings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Holds the result of a test involving multiple test cases. */
public record TestResult(List<TestCase> results, List<String> studentCode) {
    public int count() {
        return results().size();
    }

    public int passed() {
        return (int) results().stream().filter(i -> i.outcome() == Outcome.Pass).count();
    }

    public int failed() {
        return (int) results().stream().filter(i -> i.outcome() == Outcome.Fail).count();
    }

    public int incomplete() {
        return (int) results().stream().filter(i -> i.outcome() == Outcome.Incomplete).count();
    }

    public boolean overallPass() {
        return count() == passed();
    }

    public List<String> labels() {
        return results().stream().map(i -> i.label()).distinct().toList();
    }

    public String studentCodeString() {
        return Strings.header("Student Code", "\n\n\n")
                + (studentCode().isEmpty() ? "none" : Strings.join(studentCode(), "\n"))
                + "\n";
    }

    public TestResult withUpdatedTestCases(List<TestCase> updated) {
        ArrayList<TestCase> newResults = new ArrayList<>(results().size());
        newResults.addAll(results());

        for (TestCase tc : updated) {
            newResults.set(tc.id() - 1, tc);
        }

        return new TestResult(Collections.unmodifiableList(newResults), studentCode());
    }
}
