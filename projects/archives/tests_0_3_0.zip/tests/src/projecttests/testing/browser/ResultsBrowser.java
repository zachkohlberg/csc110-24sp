package projecttests.testing.browser;

import projecttests.TestingException;
import projecttests.testing.TestCase;
import projecttests.testing.TestResult;
import projecttests.testing.browser.commands.Commands;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.Project;

import java.util.List;
import java.util.Scanner;

/** Allows user to query results and see different levels of detail. */
public class ResultsBrowser {
    private projecttests.util.Project project;
    private TestResult result;
    private boolean running;

    public ResultsBrowser(Project project, TestResult result) {
        this.project = project;
        this.result = result;
    }

    public void run(Scanner in) {
        running = true;
        System.out.println("Browsing results for " + project.programName() + " tests.");

        while (running) {
            System.out.println("Please enter a command.");
            String[] args = in.nextLine().split(" ");
            if (args.length == 0) {
                System.out.println("A blank line is not a command.");
                continue;
            }

            String commandId = args[0];
            CommandArgs commandArgs = CommandArgs.parse(args, 1);

            Command<ResultsBrowser> command = Commands.getById(commandId);
            if (command == null) {
                System.out.println(commandId + " is not a valid command. Printing help message:");
                System.out.println(help());
                continue;
            }

            try {
                command.run(this, commandArgs);
            } catch (TestingException e) {
                System.out.println("ERROR: " + e.getMessage());
            }
        }
    }

    public String help() {
        return """
You're currently browsing the results of the test.

Commands:
    summary     Display summary of all results
    show        Display information about one of the test cases
    code        Show your code used in this set of tests
    list        List a summary of all test cases
    help        Display help information
    quit        Quit browsing these test results

See 'help <command>' for more information on a specific command.
""";
    }

    public List<TestCase> list() {
        return result.results();
    }

    public String summary() {
        return """
Overall result: %s
Total tests: %s
Tests passed: %s
Tests failed: %s
Tests incomplete: %s
"""
                .formatted(
                        result.overallPass() ? "PASS" : "FAIL",
                        result.count(),
                        result.passed(),
                        result.failed(),
                        result.incomplete());
    }

    public TestCase getById(int id) {
        for (TestCase res : result.results()) {
            if (res.id() == id) {
                return res;
            }
        }
        return null;
    }

    public List<String> labels() {
        return result.labels();
    }

    public String studentCode() {
        return result.studentCodeString();
    }

    public void quit() {
        running = false;
    }
}
