package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

/** Display student code. */
public class Code implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, CommandArgs args) throws TestingException {
        if (args.size() > 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        System.out.println(context.studentCode());
    }

    @Override
    public String id() {
        return "code";
    }

    @Override
    public String help() {
        return
        """
Shows your code used in this set of tests.

USAGE: code
""";
    }
}
