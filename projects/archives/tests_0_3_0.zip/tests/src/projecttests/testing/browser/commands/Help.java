package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

/** Command to get help with other commands or topics. */
public class Help implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, CommandArgs args) throws TestingException {
        if (args.size() > 1) {
            throw new TestingException(id() + " expects zero or one arguments");
        }

        if (args.size() == 1) {
            Command c = Commands.getById(args.get(0));

            if (c != null) {
                System.out.println(c.help());
            } else {
                throw new TestingException(args.get(0) + " isn't a command");
            }
        } else {
            System.out.println(context.help());
        }
    }

    @Override
    public String id() {
        return "help";
    }

    @Override
    public String help() {
        return
        """
Displays a help message for the result browser or a command.

USAGE:  help
        help COMMAND

Examples:

help
help show
help list
""";
    }
}
