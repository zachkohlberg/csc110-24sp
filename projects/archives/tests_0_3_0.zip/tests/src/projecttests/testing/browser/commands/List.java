package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.LineStatus;
import projecttests.testing.Outcome;
import projecttests.testing.TestCase;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

import java.util.function.Predicate;
import java.util.stream.Collectors;

/** Command to list all test results. */
public class List implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, CommandArgs args) throws TestingException {
        Predicate<TestCase> outcomeFilter, labelFilter;
        switch (args.size()) {
            case 0:
                outcomeFilter = i -> true;
                labelFilter = i -> true;
                break;
            case 1:
                String arg = args.get(0);

                outcomeFilter = createOutcomeFilter(arg);
                labelFilter = i -> true;
                if (outcomeFilter == null) {
                    outcomeFilter = i -> true;
                    labelFilter = createLabelFilter(context, arg);
                }

                if (labelFilter == null) {
                    throw new TestingException(arg + " is not a valid filter or label!");
                }
                break;
            case 2:
                String outcome = args.get(0),
                       label = args.get(1);

                outcomeFilter = createOutcomeFilter(outcome);
                labelFilter = createLabelFilter(context, label);

                if (outcomeFilter == null && labelFilter == null) {
                    throw new TestingException(outcome + " is not a valid filter and " + label + " is not a valid label!");
                } else if (outcomeFilter == null) {
                    throw new TestingException(outcome + " is not a valid filter!");
                } else if (labelFilter == null) {
                    throw new TestingException(label + " is not a valid label!");
                }
                break;
            default:
                throw new TestingException(id() + " expects two or fewer arguments");
        }

        final Predicate<TestCase> finalOutcomeFilter = outcomeFilter,
              finalLabelFilter = labelFilter;

        System.out.println(
                context.list().stream()
                        .filter(i -> finalOutcomeFilter.test(i) && finalLabelFilter.test(i))
                        .map(i -> i.summaryString())
                        .collect(Collectors.joining("\n")));
    }

    private Predicate<TestCase> createLabelFilter(ResultsBrowser context, String label) {
        if (context.labels().contains(label)) {
            return i -> i.label().equals(label);
        }

        return null;
    }

    private Predicate<TestCase> createOutcomeFilter(String outcome) {
        return switch (outcome) {
            case "pass" -> i -> i.outcome() == Outcome.Pass;
            case "fail" -> i -> i.outcome() == Outcome.Fail;
            case "nopass" -> i -> i.outcome() != Outcome.Pass;
            case "i", "incomplete" -> i -> i.outcome() == Outcome.Incomplete;
            case "all" -> i -> true;
            default -> null;
        };
    }

    @Override
    public String id() {
        return "list";
    }

    @Override
    public String help() {
        return """
Displays a list of each test case and its results.

USAGE: list [LABEL] [FILTER]

LABEL can be any label for a group of test cases. If no LABEL is given, then
test cases from all groups will be shown.

FILTER options:
    pass            test cases that passed
    nopass          test cases that did not pass
    fail            test cases that finished their tests and failed
    i, incomplete   test cases that did not finish
    all             all test cases (default)
""";
    }
}
