package projecttests.testing.input.generators;

import projecttests.logging.Logger;
import projecttests.testing.input.Project2Input;
import projecttests.util.Strings;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Stream;

/** Generates random inputs for project set 2. */
public final class Project2 {
    public static List<Project2Input> generate(Supplier<Project2Input> f, int count) {
        return Stream.generate(f).limit(count).toList();
    }

    public static final class Part1 {
        public static Project2Input game() {
            return new Project2Input(
                    Strings.joinDelimited(
                            "\n",
                            Random.str("yes", "no"),
                            Random.subsetConcat(1, 5, "0", "1", "2", "3", "4")),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input rollAllDice() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, Random.seed());
        }

        public static Project2Input rollSomeDice() {
            return new Project2Input(
                    null,
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    Random.subsetConcat(1, 5, "0", "1", "2", "3", "4"),
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input diceString() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, null);
        }
    }

    public static final class Part2 {
        public static Project2Input game() {
            return new Project2Input(
                    Strings.joinDelimited("\n", rerollPhaseScanner(), scorePhaseScanner()),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input rerollPhase() {
            return new Project2Input(
                    rerollPhaseScanner(),
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input scorePhase() {
            return new Project2Input(
                    scorePhaseScanner(),
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input rollAllDice() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, Random.seed());
        }

        public static Project2Input rollSomeDice() {
            return new Project2Input(
                    null,
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    Random.subsetConcat(1, 5, "a", "b", "c", "d", "e"),
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input diceString() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, null);
        }

        public static Project2Input scoreString() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, null);
        }

        public static Project2Input countDice() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, Random.die(6), null);
        }

        public static Project2Input calculateDiceScore() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, Random.nextInt(6), null, null);
        }

        private static String rerollPhaseScanner() {
            int rolls = Random.nextInt(3);
            int skip = rolls == 2 ? 0 : 1;
            int errors = Random.nextInt(2) * Random.nextInt(2) * Random.nextInt(1, 10);
            String[] commands = new String[rolls + errors + skip];
            if (skip == 1) {
                commands[commands.length - 1] = "skip";
            } else {
                commands[commands.length - 1] = rollCommand();
                --rolls;
            }

            for (int i = 0; i < commands.length - 1; ++i) {
                if (Random.nextInt(rolls + errors) < rolls) {
                    commands[i] = rollCommand();
                    --rolls;
                } else {
                    commands[i] = errorCommand();
                    --errors;
                }
            }

            return Strings.joinDelimited("\n", commands);
        }

        private static String rollCommand() {
            return "roll " + Random.subsetConcat(1, 5, "a", "b", "c", "d", "e");
        }

        private static String errorCommand() {
            return Random.str(
                    "/roll d20+3",
                    "rolling",
                    "rolled",
                    "rolllllllll",
                    "rrrrrrrroll",
                    "reroll",
                    "rofl",
                    "bowl",
                    "role",
                    "sole",
                    "mole",
                    "goal",
                    "troll",
                    "error",
                    "skipping",
                    "skipped",
                    "skibidi",
                    "sink",
                    "sip",
                    "tip",
                    "rip",
                    "clip",
                    "trip",
                    "supererror",
                    "imnotanerroriswear",
                    "superduperextraerror",
                    "thisisnotavalidcommand",
                    "thisistotallyavalidcommand",
                    "thisiswhyyouusecamelcasewhennamingvariables",
                    "win",
                    "yahtzee",
                    "gimmepoints",
                    "forfeit",
                    "/hack computer");
        }

        private static String scorePhaseScanner() {
            int errors = Random.nextInt(2) * Random.nextInt(2) * Random.nextInt(1, 10);
            String[] commands = new String[errors + 1];
            commands[commands.length - 1] = "" + (Random.nextInt(6) + 1);

            for (int i = 0; i < errors; ++i) {
                commands[i] = "" + Random.nextInt(-100, 1, 7, 100);
            }

            return Strings.joinDelimited("\n", commands);
        }
    }

    public static final class Part3 {}
}
