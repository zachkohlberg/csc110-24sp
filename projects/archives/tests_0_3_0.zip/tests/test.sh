#!/bin/sh

java --class-path "tests/bin/program/:tests/student/bin/" projecttests.Main "$@"
