package projecttests.testing.input;

import java.util.function.Function;

/** Represents input types for project 2 tests. */
public record Project2Input(
        String userInputScanner,
        int[] diceArray,
        int[] scoresArray,
        boolean[] scoreCategoriesUsed,
        String[] scoreCategoryNames,
        String rerollLabels,
        Integer scoreCategoryIndex,
        Integer dieValue,
        Long seed) {
    @Override
    public String toString() {
        return display();
    }

    public String display() {
        StringBuilder builder = new StringBuilder();
        appendIfNotNull(
                builder, userInputScanner(), "User Input Scanner", Convert.Display::scanner);
        appendIfNotNull(builder, diceArray(), "Dice Array", Convert.Display::intArray);
        appendIfNotNull(builder, scoresArray(), "Scores Array", Convert.Display::intArray);
        appendIfNotNull(
                builder,
                scoreCategoriesUsed(),
                "Score Categories Used",
                Convert.Display::booleanArray);
        appendIfNotNull(
                builder,
                scoreCategoryNames(),
                "Score Category Names",
                Convert.Display::stringArray);
        appendIfNotNull(builder, rerollLabels(), "Reroll Labels", Convert.Display::string);
        appendIfNotNull(
                builder, scoreCategoryIndex(), "Score Category Index", Convert.Display::obj);
        appendIfNotNull(builder, dieValue(), "Die Value", Convert.Display::obj);
        return builder.toString().trim();
    }

    private static <T> void appendIfNotNull(
            StringBuilder builder, T t, String label, Function<T, String> converter) {
        if (t != null) {
            builder.append(label).append(" = ").append(converter.apply(t)).append("\n");
        }
    }

    public static Project2Input decode(String s) {
        String[] args = Convert.Decode.args(s);
        return new Project2Input(
                Convert.Decode.scanner(args[0]),
                Convert.Decode.intArray(args[1]),
                Convert.Decode.intArray(args[2]),
                Convert.Decode.booleanArray(args[3]),
                Convert.Decode.stringArray(args[4]),
                Convert.Decode.string(args[5]),
                Convert.Decode.boxedInt(args[6]),
                Convert.Decode.boxedInt(args[7]),
                Convert.Decode.boxedLong(args[8]));
    }

    public static String encode(Project2Input a) {
        return Convert.Encode.args(
                new String[] {
                    Convert.Encode.scanner(a.userInputScanner()),
                    Convert.Encode.intArray(a.diceArray()),
                    Convert.Encode.intArray(a.scoresArray()),
                    Convert.Encode.booleanArray(a.scoreCategoriesUsed()),
                    Convert.Encode.stringArray(a.scoreCategoryNames()),
                    Convert.Encode.string(a.rerollLabels()),
                    Convert.Encode.boxedInt(a.scoreCategoryIndex()),
                    Convert.Encode.boxedInt(a.dieValue()),
                    Convert.Encode.boxedLong(a.seed()),
                });
    }
}
