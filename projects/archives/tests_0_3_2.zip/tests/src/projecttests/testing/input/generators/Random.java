package projecttests.testing.input.generators;

import projecttests.util.Strings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

/** Useful methods for generating random input values. */
public final class Random {
    private static ThreadLocalRandom r() {
        return ThreadLocalRandom.current();
    }

    public static long seed() {
        return r().nextLong();
    }

    public static int die(int size) {
        return r().nextInt(1, size + 1);
    }

    public static int[] dice(int size, int count) {
        return IntStream.generate(() -> die(size)).limit(count).toArray();
    }

    public static int nextInt(int bound) {
        return r().nextInt(bound);
    }

    public static int nextInt(int origin, int bound) {
        return r().nextInt(origin, bound);
    }

    public static int nextInt(int origin1, int bound1, int origin2, int bound2) {
        if (origin1 >= bound1 || bound1 > origin2 || origin2 >= bound2) {
            throw new IllegalArgumentException(
                    "arguments must meet the following requirements: origin1 < bound1, bound1 <="
                        + " origin2, origin2 < bound2");
        }
        int n = r().nextInt(origin1, bound1 + bound2 - origin2);
        if (n < bound1) {
            return n;
        }
        return n + origin2 - bound1;
    }

    public static String str(String... options) {
        return options[r().nextInt(options.length)];
    }

    public static List<String> subset(String... options) {
        return subset(0, options.length, options);
    }

    public static List<String> subset(int count, String... options) {
        ArrayList<String> list = new ArrayList<>(Arrays.asList(options));
        Collections.shuffle(list);
        return list.subList(0, count);
    }

    public static List<String> subset(int minCount, int maxCount, String... options) {
        return subset(r().nextInt(minCount, maxCount + 1), options);
    }

    public static String subsetConcat(String... options) {
        return Strings.join(subset(options));
    }

    public static String subsetConcat(int count, String... options) {
        return Strings.join(subset(count, options));
    }

    public static String subsetConcat(int minCount, int maxCount, String... options) {
        return Strings.join(subset(minCount, maxCount, options));
    }
}
