#!/bin/sh

# classpath separators are different on Windows, and you're probably using the
# msys terminal emulator (git bash)
if [ "$OSTYPE" = "msys" ] || [ "$OSTYPE" = "cygwin" ]; then
    java --class-path "tests/bin/program/;tests/student/bin/" projecttests.Main "$@"
else
    java --class-path "tests/bin/program/:tests/student/bin/" projecttests.Main "$@"
fi
