package projecttests.testing;

import projecttests.Main;
import projecttests.TestingException;
import projecttests.logging.Logger;
import projecttests.testing.input.Convert;
import projecttests.testing.input.Project2Input;
import projecttests.util.FileIO;
import projecttests.util.Project;
import projecttests.util.Strings;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/** Tests one of a Java class's functions. */
public class JavaFunctionTest {
    private Project project;
    private String groupLabel;
    private int nextId;
    private Function<Project2Input, List<String>> test;
    private List<Project2Input> input;
    private List<TestCase> testCases;
    private Path dataPath,
            inputPath,
            expectedOutputPath,
            expectedParamsAfterPath,
            expectedReturnValuePath;

    public JavaFunctionTest(
            Project project,
            String groupLabel,
            int nextId,
            Function<Project2Input, List<String>> test)
            throws TestingException {
        this.project = project;
        this.groupLabel = groupLabel;
        this.nextId = nextId;
        this.test = test;

        dataPath = Main.settings().dataPath().resolve(project.path()).resolve(groupLabel);
        inputPath = dataPath.resolve("input.txt");
        expectedOutputPath = dataPath.resolve("expected-output.txt");
        expectedParamsAfterPath = dataPath.resolve("expected-params-after.txt");
        expectedReturnValuePath = dataPath.resolve("expected-return-value.txt");
    }

    public int nextId() {
        return nextId;
    }

    private void loadTestCasesAndInput() throws TestingException {
        Supplier<TestingException> error =
                () ->
                        new TestingException(
                                "Could not load resource for " + groupLabel + " test cases.");

        List<String> inputList = FileIO.loadOrElseThrow(inputPath, error),
                expectedOutputList = FileIO.loadOrElseThrow(expectedOutputPath, error),
                expectedParamsAfterList = FileIO.loadOrElseThrow(expectedParamsAfterPath, error),
                expectedReturnValueList = FileIO.loadOrElseThrow(expectedReturnValuePath, error);

        input = new ArrayList<>();
        testCases = new ArrayList<>();
        for (int i = 0; i < inputList.size(); ++i) {
            Project2Input inputItem = Project2Input.decode(inputList.get(i));

            List<String> programInput =
                    inputItem.userInputScanner() != null
                            ? Arrays.asList(inputItem.userInputScanner().split("\n"))
                            : Collections.emptyList();
            List<String> expectedOutput =
                    Processing.cleanOutput(Convert.Decode.lines(expectedOutputList.get(i)));
            List<String> paramsBefore =
                    Processing.cleanOutput(Arrays.asList(inputItem.display(false).split("\n")));
            List<String> expectedParamsAfter =
                    Processing.cleanOutput(Convert.Decode.lines(expectedParamsAfterList.get(i)));
            List<String> expectedReturnValue =
                    Processing.cleanOutput(Convert.Decode.lines(expectedReturnValueList.get(i)));

            TestCase testCase =
                    TestCase.untested(
                            groupLabel,
                            nextId,
                            programInput,
                            expectedOutput,
                            paramsBefore,
                            expectedParamsAfter,
                            expectedReturnValue);

            input.add(inputItem);
            testCases.add(testCase);
            ++nextId;
        }
    }

    public void generateData(List<Project2Input> input) {
        ArrayList<String> inputList = new ArrayList<>(),
                expectedOutputList = new ArrayList<>(),
                expectedParamsAfterList = new ArrayList<>(),
                expectedReturnValueList = new ArrayList<>(),
                errors = new ArrayList<>();

        PrintStream systemOut = System.out;
        PrintStream systemErr = System.err;

        for (int i = 0; i < input.size(); ++i) {
            try (ByteArrayOutputStream bufferOut = new ByteArrayOutputStream();
                    ByteArrayOutputStream bufferErr = new ByteArrayOutputStream();
                    PrintStream printOut = new PrintStream(bufferOut);
                    PrintStream printErr = new PrintStream(bufferErr)) {
                System.setOut(printOut);
                System.setErr(printErr);

                Project2Input in = input.get(i);

                inputList.add(Project2Input.encode(in));
                expectedReturnValueList.add(Strings.join(test.apply(in), Convert.LINE_DELIMITER));
                expectedOutputList.add(
                        Arrays.asList(bufferOut.toString().split("\n")).stream()
                                .filter(line -> line != null && !line.isBlank())
                                .filter(line -> !line.startsWith("##"))
                                .collect(Collectors.joining(Convert.LINE_DELIMITER)));
                expectedParamsAfterList.add(in.display(true).replace("\n", Convert.LINE_DELIMITER));
                errors.addAll(
                        Arrays.asList(bufferErr.toString().split("\n")).stream()
                                .filter(line -> !line.isBlank())
                                .toList());
            } catch (IOException e) {
                Logger.error(e, "IOException when closing output stream.");
            }
        }

        System.setOut(systemOut);
        System.setErr(systemErr);

        if (errors.size() > 0) {
            System.out.println("Errors encountered: " + Strings.join(errors, "\n"));
        }

        try {
            Files.createDirectories(dataPath);
            Files.write(
                    inputPath,
                    inputList,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
            Files.write(
                    expectedOutputPath,
                    expectedOutputList,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
            Files.write(
                    expectedParamsAfterPath,
                    expectedParamsAfterList,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
            Files.write(
                    expectedReturnValuePath,
                    expectedReturnValueList,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            Logger.error(e, "IOException when saving data.");
        }
    }

    public List<TestCase> run() throws TestingException {
        loadTestCasesAndInput();

        ArrayList<TestCase> finishedTestCases = new ArrayList<>(testCases.size());

        PrintStream systemOut = System.out;
        PrintStream systemErr = System.err;

        for (int i = 0; i < testCases.size(); ++i) {
            try (ByteArrayOutputStream bufferOut = new ByteArrayOutputStream();
                    ByteArrayOutputStream bufferErr = new ByteArrayOutputStream();
                    PrintStream printOut = new PrintStream(bufferOut);
                    PrintStream printErr = new PrintStream(bufferErr)) {
                System.setOut(printOut);
                System.setErr(printErr);

                TestCase tc = testCases.get(i);
                Project2Input in = input.get(i);

                List<String> studentReturnValue = test.apply(in);
                List<String> studentOutput =
                        Arrays.asList(bufferOut.toString().split("\n")).stream()
                                .filter(line -> line != null && !line.isBlank())
                                .toList();
                List<String> studentParamsAfter = Arrays.asList(in.display(true).split("\n"));
                List<String> errors =
                        Arrays.asList(bufferErr.toString().split("\n")).stream().toList();
                List<String> feedback =
                        in.seed() != null
                                ? List.of("RNG Seed = " + in.seed())
                                : Collections.emptyList();

                TestCase.Result r =
                        TestCase.Result.unchecked(
                                studentOutput,
                                studentParamsAfter,
                                studentReturnValue,
                                errors,
                                feedback);

                finishedTestCases.add(evaluateTestCase(tc, r));
            } catch (IOException e) {
                Logger.error(e, "IOException when closing output stream.");
                // TODO: should we do anything else here to handle exceptions?
            }
        }

        System.setOut(systemOut);
        System.setErr(systemErr);

        return Collections.unmodifiableList(finishedTestCases);
    }

    private TestCase evaluateTestCase(TestCase incomplete, TestCase.Result result) {
        ArrayList<OutputLine> studentOutput = new ArrayList<>(),
                expectedOutput = new ArrayList<>(),
                studentParamsAfter = new ArrayList<>(),
                expectedParamsAfter = new ArrayList<>(),
                studentReturnValue = new ArrayList<>(),
                expectedReturnValue = new ArrayList<>();
        TestCase.checkOutput(
                result.studentOutput(),
                incomplete.expectedOutput(),
                studentOutput,
                expectedOutput,
                LineStatus.NO_MATCH,
                LineStatus.ERROR);
        TestCase.checkOutput(
                result.studentParamsAfter(),
                incomplete.expectedParamsAfter(),
                studentParamsAfter,
                expectedParamsAfter,
                LineStatus.ERROR,
                LineStatus.ERROR);
        TestCase.checkOutput(
                result.studentReturnValue(),
                incomplete.expectedReturnValue(),
                studentReturnValue,
                expectedReturnValue,
                LineStatus.ERROR,
                LineStatus.ERROR);
        return new TestCase(
                incomplete.label(),
                incomplete.id(),
                incomplete.programInput(),
                Collections.unmodifiableList(expectedOutput),
                incomplete.paramsBefore(),
                Collections.unmodifiableList(expectedParamsAfter),
                Collections.unmodifiableList(expectedReturnValue),
                OutputLine.allOkay(
                                List.of(
                                        expectedOutput,
                                        expectedParamsAfter,
                                        expectedReturnValue,
                                        studentOutput,
                                        studentParamsAfter,
                                        studentReturnValue))
                        ? Outcome.Pass
                        : Outcome.Fail,
                new TestCase.Result(
                        Collections.unmodifiableList(studentOutput),
                        Collections.unmodifiableList(studentParamsAfter),
                        Collections.unmodifiableList(studentReturnValue),
                        result.errors(),
                        result.feedback()));
    }
}
