package projecttests.testing;

public enum Outcome {
    Pass(true),
    Fail(false),
    Incomplete(false);

    public final boolean pass;

    Outcome(boolean pass) {
        this.pass = pass;
    }
}
