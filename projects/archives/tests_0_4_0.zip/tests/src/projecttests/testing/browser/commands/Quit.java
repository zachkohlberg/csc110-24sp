package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

/** Quits the results browser. */
public class Quit implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, CommandArgs args) throws TestingException {
        if (args.size() > 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        context.quit();
    }

    @Override
    public String id() {
        return "quit";
    }

    @Override
    public String help() {
        return
        """
Quits browsing these results.

USAGE: quit
""";
    }
}
