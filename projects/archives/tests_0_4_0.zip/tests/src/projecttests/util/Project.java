package projecttests.util;

import projecttests.Main;
import projecttests.TestingException;
import projecttests.testing.TestResult;

import java.nio.file.Path;
import java.util.List;

/** Defines interface for individual or groups of projects. */
public interface Project extends HasId {
    String programName();

    Path path();

    boolean compiles();

    default Path programFilePath() {
        return path().resolve(programName());
    }

    default List<Path> projectFilePaths() {
        return List.of(path().resolve(programName()));
    }

    default boolean checkProjectFiles() {
        for (Path p : projectFilePaths()) {
            if (!FileIO.exactRelativePathExists(p)) {
                return false;
            }
        }

        return true;
    }

    default Path recordFilePath() {
        return Main.settings().studentRecordsPath().resolve(path()).resolve(Main.RECORD_FILENAME);
    }

    default Path programFileBackupPath() {
        return Main.settings().studentBackupsPath().resolve(programFilePath());
    }

    TestResult test() throws TestingException;

    void generateIO() throws TestingException;
}
