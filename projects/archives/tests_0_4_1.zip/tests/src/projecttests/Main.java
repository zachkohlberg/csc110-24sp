package projecttests;

import projecttests.commands.Commands;
import projecttests.logging.Logger;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/** Launches the test program for a student. */
public class Main {
    public static final String COMMAND = "sh tests/test.sh";
    public static final String RECORD_FILENAME = "record.txt";
    public static final String VERSION = "0.4.1";

    private static Settings settings;

    public static Settings settings() {
        return settings;
    }

    public static void main(String[] args) {
        ProgramArgs programArgs = null;
        try {
            programArgs = parseArgs(args);

            settings = getSettings(programArgs);
        } catch (Throwable e) {
            e.printStackTrace(System.err);
            System.out.println("Printing main help message:");
            System.out.println(help());
            System.exit(1);
        }

        startLogger();
        Logger.info("Program version = " + Main.VERSION);

        int exitCode;
        try {
            programArgs.cmd().run(null, programArgs.cmdArgs());
            exitCode = 0;
        } catch (Throwable e) {
            Logger.error(e, "Encountered an error while running command: " + e.getMessage()).print();
            exitCode = 1;
        }

        if (Logger.logging()) {
            Logger.stop();
        }
        System.exit(exitCode);
    }

    private static ProgramArgs parseArgs(String[] args) throws TestingException {
        List<String> argList = Arrays.asList(args);

        List<String> flagList = argList.stream().takeWhile(i -> i.startsWith("--")).toList();
        HashMap<String, String> flags = CommandArgs.parseFlags(flagList);

        if (flagList.size() == argList.size()) {
            throw new TestingException("No command provided!");
        }

        String cmdString = argList.get(flagList.size());
        Command<Main> cmd = Commands.getById(cmdString);
        if (cmd == null) {
            throw new TestingException(cmdString + " is not a valid command!");
        }

        CommandArgs cmdArgs = CommandArgs.parse(args, flagList.size() + 1);

        return new ProgramArgs(flags, cmd, cmdArgs);
    }

    private static Settings getSettings(ProgramArgs args) {
        Path binPath =
                FileSystems.getDefault()
                        .getPath(args.flags().getOrDefault("bin-path", "tests/bin/program"));
        Path logPath =
                FileSystems.getDefault()
                        .getPath(args.flags().getOrDefault("log-path", "tests/logs"));
        Path projectsPath =
                FileSystems.getDefault().getPath(args.flags().getOrDefault("projects-path", "."));
        Path resPath =
                FileSystems.getDefault()
                        .getPath(args.flags().getOrDefault("resource-path", "tests/res"));
        Path srcPath =
                FileSystems.getDefault().getPath(args.flags().getOrDefault("src-path", "test/src"));
        Path studentPath =
                FileSystems.getDefault()
                        .getPath(args.flags().getOrDefault("student-path", "tests/student"));

        int timeout, maxThreads, retries;
        try {
            timeout = Integer.parseInt(args.flags().getOrDefault("timeout", "300"));
            if (timeout < 1) {
                throw new IllegalArgumentException("The timeout must be a positive integer.");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("The timeout must be a positive integer.", e);
        }

        try {
            maxThreads = Integer.parseInt(args.flags().getOrDefault("max-threads", "50"));
            if (maxThreads < 1) {
                throw new IllegalArgumentException("The max-threads must be a positive integer.");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("The max-threads must be a positive integer.", e);
        }

        try {
            retries = Integer.parseInt(args.flags().getOrDefault("retries", "0"));
            if (retries < 0) {
                throw new IllegalArgumentException("The retries must be a nonnegative integer.");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("The retries must be a nonnegative integer.", e);
        }

        return new Settings(
                binPath,
                logPath,
                projectsPath,
                resPath,
                srcPath,
                studentPath,
                timeout,
                maxThreads,
                retries);
    }

    private static void startLogger() {
        try {
            Logger.start(settings().logPath());
        } catch (IOException e) {
            System.err.println(
                    """
ERROR: Failed to initialize logger!

This is likely a result of running this program from the wrong location. Make
sure you're in your projects folder, not the tests folder, and that you
extracted tests.zip correctly. The file tests/README.txt includes directions for
extracting tests.zip. If you fix both of these problems or confirm they aren't
present and this error still occurs, then ask for help.

The program will still run if possible, but no log will be recorded.

Below is a stack trace for the IOException that occurred when trying to
initialize the logger:
""");
            e.printStackTrace(System.err);
        }
    }

    public static String help() {
        return """
Tests and packages your projects.

Usage: {COMMAND} [FLAG]... COMMAND

Commands:
    test        Run tests for one or more projects
    status      Display the status of your projects
    pack        Package projects for submission on Blackboard
    help        Display help messages
    version     Display program's version number
    gen         Uses your project to generate new i/o data for the test

Flags:
    --projects-path=<path>
        Search <path> for student projects instead of the working directory.
    --student-path=<path>
        Save student information to <path> instead of "tests/student".
    --log-path=<path>
        Save log files to <path> instead of "tests/logs".
    --resource-path=<path>
        Search for resource files in <path> instead of "tests/res".
    --bin-path=<path>
        Search for this program's source code in <path> instead of "tests/src".
    --src-path=<path>
        Search for compiled test program files in <path> instead of "tests/bin".
    --max-threads=<n>
        Limit the number of threads for Jshell tests to <n>. This is the number
        of test cases that the program will attempt to run concurrently, and it
        defaults to 50. Lowering the number may help if tests repeatedly crash
        or timeout.
    --timeout=<t>
        Allow tests to run for up to <t> seconds before ending the test with a
        timeout error. This defaults to 300, and if your computer takes too long
        to run the tests then you may want to raise this number. A timeout is
        necessary to handle errors that cause your code to run indefinitely,
        such as infinite loops.
    --retries=<r>
        Automatically retries Jshell test cases that did not complete up to <r>
        times. This will not retry tests that failed due to incorrect output. It
        only applies to test cases that timed out or encountered an unexpected
        error that may not be related to your program (such test cases are
        marked as incomplete in the results summary.

See '{COMMAND} help COMMAND' for more information on a specific command.
"""
                .replace("{COMMAND}", COMMAND);
    }

    static record ProgramArgs(
            HashMap<String, String> flags, Command<Main> cmd, CommandArgs cmdArgs) {}

    public static record Settings(
            Path binPath,
            Path logPath,
            Path projectsPath,
            Path resPath,
            Path srcPath,
            Path studentPath,
            int timeout,
            int maxThreads,
            int retries) {
        public Path dataPath() {
            return resPath().resolve("data");
        }

        public Path jshPath() {
            return resPath().resolve("jsh");
        }

        public Path studentBackupsPath() {
            return studentPath().resolve("backups");
        }

        public Path studentBinPath() {
            return studentPath().resolve("bin");
        }

        public Path studentRecordsPath() {
            return studentPath().resolve("records");
        }

        public Path studentSrcPath() {
            return studentPath().resolve("src");
        }
    }
}
