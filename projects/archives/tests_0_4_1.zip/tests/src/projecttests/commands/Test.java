package projecttests.commands;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.projects.Projects;
import projecttests.testing.TestResult;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.Project;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** Runs the tests for one or more projects. */
public class Test implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        if (args.size() == 0) {
            throw new TestingException(id() + " expects at least one argument");
        }

        List<Project> projects = new ArrayList<>();
        for (String arg : args) {
            Project p = Projects.getById(arg);
            if (p == null) {
                throw new TestingException(arg + " is not a valid project");
            }
            projects.add(p);
        }

        Scanner in = new Scanner(System.in);
        for (Project p : projects) {
            TestResult result = p.test();

            Logger.info("Saving overall result");

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            try {
                Files.createDirectories(p.recordFilePath().getParent());
                Files.write(
                        p.recordFilePath(),
                        List.of(result.overallPass() ? "PASS" : "FAIL", timestamp),
                        StandardOpenOption.CREATE,
                        StandardOpenOption.TRUNCATE_EXISTING);
            } catch (IOException e) {
                Logger.error(e, "IOException while recording test result").print();
            }

            ResultsBrowser browser = new ResultsBrowser(p, result);
            browser.run(in);
        }
    }

    @Override
    public String id() {
        return "test";
    }

    @Override
    public String help() {
        return """
Tests a project or a group of projects.

USAGE: {COMMAND} test PROJECT [PROJECT]...

Valid project names: 1.1, 1.2, 2.1, 2.2, 2.3

Not yet implemented (currently invalid): 3.1, 3.2

Examples:

{COMMAND} test 1.1
{COMMAND} test 1.2
{COMMAND} test 1.1 1.2 2.1 3.1
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
