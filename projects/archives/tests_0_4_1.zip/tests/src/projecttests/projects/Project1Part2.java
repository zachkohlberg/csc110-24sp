package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JshellIOTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestResult;
import projecttests.util.Project;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

/** Tests for project 1 part 2. */
public class Project1Part2 implements Project {
    @Override
    public String id() {
        return "1.2";
    }

    @Override
    public String programName() {
        return "CharacterSheet2.jsh";
    }

    @Override
    public boolean compiles() {
        return false;
    }

    @Override
    public Path path() {
        return FileSystems.getDefault().getPath("project1", "part2");
    }

    @Override
    public TestResult test() throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this);
        preprocessor.run(null);
        JshellIOTest test = new JshellIOTest(this);
        return test.run();
    }

    @Override
    public void generateIO() throws TestingException {
        throw new UnsupportedOperationException("not yet implemented");
    }

    public static List<String> sampleInputs(int size) {
        String[] inputs = new String[size];
        for (int i = 0; i < size; ++i) {
            inputs[i] =
                    String.format(
                            "%s|%s|%s|%s|%s|%s|%s|%s",
                            Project1Inputs.randomBeefAndDairyActor(),
                            Project1Inputs.randomBeefAndDairyCharacter(),
                            Project1Inputs.randomAncestry(),
                            Project1Inputs.randomClass(),
                            Project1Inputs.randomLevel(),
                            Project1Inputs.randomAbilityScore(),
                            Project1Inputs.randomAbilityScore(),
                            Project1Inputs.randomAbilityScore());
        }
        return Arrays.asList(inputs);
    }
}
