package student.project2.part3;

/** Placeholder for 2.3 so other test code can compile. */
public class DiceGame {
    // Require Dice.java to compile
    private Dice __;

    public static void game(java.util.Scanner a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void rerollPhase(java.util.Scanner a, int[] b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void scorePhase(java.util.Scanner a, int[] b, int[] c, boolean[] d, String[] e) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int countDice(int[] a, int b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int totalScore(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int upperTotal(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int upperBonus(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int lowerTotal(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateDiceScore(int[] a, int b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateUpperCategory(int[] a, int b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateThreeOfAKind(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateFourOfAKind(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateFullHouse(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateSmallStraight(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateLargeStraight(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateYahtzee(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateChance(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void rollAllDice(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void rollSomeDice(int[] a, String b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static String diceString(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static String scoreString(int[] a, boolean[] b, String[] c, int[] d) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }
}
