package projecttests.commands;

import projecttests.*;
import projecttests.projects.Projects;
import projecttests.testing.TestResult;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.Project;

import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** Generates i/o data for a project using your program. */
public class Gen implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        if (args.size() != 1) {
            throw new TestingException(id() + " expects one argument");
        }

        // This command isn't for students to use, but I want to include it in
        // main codebase so I don't have to compile a separate program for it.
        // Rather than look into some compilation setting, this is a quick and
        // dirty way of disabling it so that a student doesn't accidentally
        // mess up their test data and get a false positive when testing their
        // program.
        if (!Files.exists(FileSystems.getDefault().getPath("gen.txt"))) {
            throw new TestingException(id() + " command is not enabled");
        }

        Project p = Projects.getById(args.get(0));
        if (p == null || p.id().equals("1.1") || p.id().equals("1.2")) {
            throw new TestingException(args.get(0) + " is not a valid project");
        }

        p.generateIO();
    }

    @Override
    public String id() {
        return "gen";
    }

    @Override
    public String help() {
        return
                """
Generates io data for a project. Not enabled by default to avoid students
generating new io data and seeing a false positive result when testing their
code.

USAGE: {COMMAND} gen PROJECT

Valid project names: 2.1, 2.2, 2.3

Not yet implemented (currently invalid): 1.1, 1.2, 3.1, 3.2

Examples:

{COMMAND} gen 2.1
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
