package projecttests.testing;

/** Represents each possible status for a line of output. */
public enum LineStatus {
    MATCH,
    NO_MATCH,
    ERROR,
    UNCHECKED,
}
