package projecttests.testing;

import projecttests.util.Strings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

/** Holds all information about a test case. */
public record TestCase(
        String label,
        int id,
        List<String> programInput,
        List<OutputLine> expectedOutput,
        List<String> paramsBefore,
        List<OutputLine> expectedParamsAfter,
        List<OutputLine> expectedReturnValue,
        Outcome outcome,
        Result result) {

    public static TestCase untested(
            String label,
            int id,
            List<String> programInput,
            List<String> expectedOutput,
            List<String> paramsBefore,
            List<String> expectedParamsAfter,
            List<String> expectedReturnValue) {
        return new TestCase(
                label,
                id,
                programInput,
                OutputLine.uncheckedList(expectedOutput),
                paramsBefore,
                OutputLine.uncheckedList(expectedParamsAfter),
                OutputLine.uncheckedList(expectedReturnValue),
                Outcome.Incomplete,
                Result.empty());
    }

    public TestCase incomplete(List<String> errors, List<String> feedback) {
        return new TestCase(
                label(),
                id(),
                programInput(),
                expectedOutput(),
                paramsBefore(),
                expectedParamsAfter(),
                expectedReturnValue(),
                Outcome.Incomplete,
                new Result(
                        Collections.emptyList(),
                        Collections.emptyList(),
                        Collections.emptyList(),
                        errors,
                        feedback));
    }

    public String summaryString() {
        return "%s %s: %s (%s)".formatted(label(), id(), outcome(), scoresString());
    }

    private String scoresString() {
        ArrayList<String> scores = new ArrayList<>();

        addScoreString(scores, "output", expectedOutput());
        addScoreString(scores, "params", expectedParamsAfter());
        addScoreString(scores, "return", expectedReturnValue());

        return Strings.join(scores, ", ");
    }

    private void addScoreString(ArrayList<String> list, String label, List<OutputLine> lines) {
        if (!lines.isEmpty()) {
            list.add(
                    label
                            + ": "
                            + lines.stream().filter(i -> i.status() == LineStatus.MATCH).count()
                            + "/"
                            + lines.size());
        }
    }

    public String headerString() {
        return "%sLabel: %s\nID: %s\nResult: %s\n"
                .formatted(Strings.header("Test Result", "\n\n"), label(), id(), outcome());
    }

    public String inputString() {
        ArrayList<String> list = new ArrayList<>();

        addSubcategory(list, "Program Input", programInput());
        addSubcategory(list, "Function Parameters (Before)", paramsBefore());

        return listString("Input", list);
    }

    public String studentOutputString() {
        return studentOutputString(i -> true);
    }

    public String studentOutputString(Predicate<LineStatus> filter) {
        ArrayList<String> list = new ArrayList<>();

        addOutputSubcategory(list, "Student Program Output", result().studentOutput(), filter);
        addOutputSubcategory(
                list, "Student Function Parameters (After)", result().studentParamsAfter(), filter);
        addOutputSubcategory(
                list, "Student Function Return Value", result().studentReturnValue(), filter);

        return listString("Student Output", list);
    }

    public String expectedOutputString() {
        return expectedOutputString(i -> true);
    }

    public String expectedOutputString(Predicate<LineStatus> filter) {
        ArrayList<String> list = new ArrayList<>();

        addOutputSubcategory(list, "Expected Program Output", expectedOutput(), filter);
        addOutputSubcategory(
                list, "Expected Function Parameters (After)", expectedParamsAfter(), filter);
        addOutputSubcategory(list, "Expected Function Return Value", expectedReturnValue(), filter);

        return listString("Expected Output", list);
    }

    public String errorsString() {
        return listString("Errors", result().errors());
    }

    public String additionalFeedbackString() {
        return listString("Additional Feedback", "none", result().feedback());
    }

    public String fullInfo() {
        return inputString()
                + "\n"
                + studentOutputString()
                + "\n"
                + expectedOutputString()
                + "\n"
                + errorsString()
                + "\n"
                + additionalFeedbackString();
    }

    private void addOutputSubcategory(
            ArrayList<String> list,
            String header,
            List<OutputLine> content,
            Predicate<LineStatus> filter) {
        addSubcategory(
                list,
                header,
                content.stream()
                        .filter(i -> filter.test(i.status()))
                        .map(i -> i.toString())
                        .toList());
    }

    private void addSubcategory(ArrayList<String> list, String header, List<String> content) {
        if (content.isEmpty()) {
            return;
        }

        if (!list.isEmpty()) {
            list.add("");
        }

        list.add("**" + header + "**");
        list.add("");
        list.addAll(content);
    }

    private String listString(String header, String ifEmpty, List<String> list) {
        return Strings.header(header, "\n\n")
                + (list.isEmpty() ? ifEmpty : Strings.join(list, "\n"))
                + "\n";
    }

    private String listString(String header, List<String> list) {
        return listString(header, "", list);
    }

    public static record Result(
            List<OutputLine> studentOutput,
            List<OutputLine> studentParamsAfter,
            List<OutputLine> studentReturnValue,
            List<String> errors,
            List<String> feedback) {
        public static Result empty() {
            return new Result(
                    Collections.emptyList(),
                    Collections.emptyList(),
                    Collections.emptyList(),
                    Collections.emptyList(),
                    Collections.emptyList());
        }

        public static Result unchecked(
                List<String> studentOutput,
                List<String> studentParamsAfter,
                List<String> studentReturnValue,
                List<String> errors,
                List<String> feedback) {
            return new Result(
                    studentOutput.stream()
                            .map(i -> new OutputLine(i, LineStatus.UNCHECKED))
                            .toList(),
                    studentParamsAfter.stream()
                            .map(i -> new OutputLine(i, LineStatus.UNCHECKED))
                            .toList(),
                    studentReturnValue.stream()
                            .map(i -> new OutputLine(i, LineStatus.UNCHECKED))
                            .toList(),
                    errors,
                    feedback);
        }
    }

    public static void checkOutput(
            List<OutputLine> student,
            List<OutputLine> expected,
            ArrayList<OutputLine> studentChecked,
            ArrayList<OutputLine> expectedChecked,
            LineStatus studentNoMatch,
            LineStatus expectedNoMatch) {
        for (OutputLine expectedLine : expected) {
            if (student.stream()
                    .skip(studentChecked.size())
                    .anyMatch(line -> line.linesEqual(expectedLine))) {
                studentChecked.addAll(
                        student.stream()
                                .skip(studentChecked.size())
                                .takeWhile(line -> !line.linesEqual(expectedLine))
                                .map(line -> line.withStatus(studentNoMatch))
                                .toList());
                expectedChecked.add(expectedLine.withStatus(LineStatus.MATCH));
                studentChecked.add(expectedLine.withStatus(LineStatus.MATCH));
            } else {
                expectedChecked.add(expectedLine.withStatus(expectedNoMatch));
            }
        }
        student.stream()
                .skip(studentChecked.size())
                .forEach(line -> studentChecked.add(line.withStatus(studentNoMatch)));
    }
}
