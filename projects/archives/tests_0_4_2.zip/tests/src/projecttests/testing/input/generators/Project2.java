package projecttests.testing.input.generators;

import projecttests.logging.Logger;
import projecttests.testing.input.Project2Input;
import projecttests.util.Strings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/** Generates random inputs for project set 2. */
public final class Project2 {
    public static List<Project2Input> generate(Supplier<Project2Input> f, int count) {
        return Stream.generate(f).limit(count).toList();
    }

    private static String rerollLabelsNumbers() {
        ArrayList<String> labels = new ArrayList<>();
        labels.addAll(Random.subset(1, 5, "0", "1", "2", "3", "4"));
        Collections.sort(labels);
        return Strings.join(labels);
    }

    private static String rerollLabelsLetters() {
        ArrayList<String> labels = new ArrayList<>();
        labels.addAll(Random.subset(1, 5, "a", "b", "c", "d", "e"));
        Collections.sort(labels);
        return Strings.join(labels);
    }

    private static String rollCommand() {
        return "roll " + rerollLabelsLetters();
    }

    private static String errorCommand() {
        return Random.str(
                "/roll d20+3",
                "rolling",
                "rolled",
                "rolllllllll",
                "rrrrrrrroll",
                "reroll",
                "rofl",
                "bowl",
                "role",
                "sole",
                "mole",
                "goal",
                "troll",
                "error",
                "skipping",
                "skipped",
                "skibidi",
                "sink",
                "sip",
                "tip",
                "rip",
                "clip",
                "trip",
                "supererror",
                "imnotanerroriswear",
                "superduperextraerror",
                "thisisnotavalidcommand",
                "thisistotallyavalidcommand",
                "thisiswhyyouusecamelcasewhennamingvariables",
                "win",
                "yahtzee",
                "gimmepoints",
                "forfeit",
                "/hack computer");
    }

    private static String rerollPhaseScanner() {
        int rolls = Random.nextInt(3);
        int skip = rolls == 2 ? 0 : 1;
        int errors = Random.nextInt(2) * Random.nextInt(2) * Random.nextInt(1, 10);
        String[] commands = new String[rolls + errors + skip];
        if (skip == 1) {
            commands[commands.length - 1] = "skip";
        } else {
            commands[commands.length - 1] = rollCommand();
            --rolls;
        }

        for (int i = 0; i < commands.length - 1; ++i) {
            if (Random.nextInt(rolls + errors) < rolls) {
                commands[i] = rollCommand();
                --rolls;
            } else {
                commands[i] = errorCommand();
                --errors;
            }
        }

        return Strings.joinDelimited("\n", commands);
    }

    public static final class Part1 {
        public static Project2Input game() {
            String scanner = Strings.joinDelimited("\n", Random.str("yes", "no"), rerollLabelsNumbers());
            return new Project2Input(
                    scanner, null, null, null, null, null, null, null, Random.seed());
        }

        public static Project2Input rollAllDice() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, Random.seed());
        }

        public static Project2Input rollSomeDice() {
            return new Project2Input(
                    null,
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    rerollLabelsNumbers(),
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input diceString() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, null);
        }
    }

    public static final class Part2 {
        public static Project2Input game() {
            String scanner = Strings.joinDelimited("\n", rerollPhaseScanner(), scorePhaseScanner());
            return new Project2Input(
                    scanner, null, null, null, null, null, null, null, Random.seed());
        }

        public static Project2Input rerollPhase() {
            return new Project2Input(
                    rerollPhaseScanner(),
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input scorePhase() {
            return new Project2Input(
                    scorePhaseScanner(),
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input rollAllDice() {
            return Part1.rollAllDice();
        }

        public static Project2Input rollSomeDice() {
            return new Project2Input(
                    null,
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    rerollLabelsLetters(),
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input diceString() {
            return Part1.diceString();
        }

        public static Project2Input scoreString() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, null, null);
        }

        public static Project2Input countDice() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, null, Random.die(6), null);
        }

        public static Project2Input calculateDiceScore() {
            return new Project2Input(
                    null, Random.dice(6, 5), null, null, null, null, Random.nextInt(6), null, null);
        }

        private static String scorePhaseScanner() {
            int errors = Random.nextInt(2) * Random.nextInt(2) * Random.nextInt(1, 10);
            String[] commands = new String[errors + 1];
            commands[commands.length - 1] = "" + (Random.nextInt(6) + 1);

            for (int i = 0; i < errors; ++i) {
                commands[i] = "" + Random.nextInt(-100, 1, 7, 100);
            }

            return Strings.joinDelimited("\n", commands);
        }
    }

    public static final class Part3 {
        public static Project2Input game() {
            return new Project2Input(
                    gameScanner(), null, null, null, null, null, null, null, Random.seed());
        }

        public static Project2Input rerollPhase() {
            return new Project2Input(
                    rerollPhaseScanner(),
                    Random.dice(6, 5),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    Random.seed());
        }

        public static Project2Input scorePhase() {
            Scores scores = scores(Random.nextInt(1, 14));
            return new Project2Input(
                    scorePhaseScanner(scores.inUseArray()),
                    Random.dice(6, 5),
                    scores.scoreArray(),
                    scores.inUseArray(),
                    categoryNames(),
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input rollAllDice() {
            return Part2.rollAllDice();
        }

        public static Project2Input rollSomeDice() {
            return Part2.rollSomeDice();
        }

        public static Project2Input diceString() {
            return Part2.diceString();
        }

        public static Project2Input scoreString() {
            Scores scores = scores(Random.nextInt(2) * Random.nextInt(14));
            return new Project2Input(
                    null,
                    scorableDice(-1),
                    scores.scoreArray(),
                    scores.inUseArray(),
                    categoryNames(),
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input countDice() {
            return Part2.countDice();
        }

        public static Project2Input calculateDiceScore() {
            int category = Random.nextInt(13);
            int[] dice = Random.coinflip() ? scorableDice(-1) : scorableDice(category);
            return new Project2Input(null, dice, null, null, null, null, category, null, null);
        }

        public static Project2Input totalScore() {
            return new Project2Input(
                    null,
                    null,
                    scores(Random.nextInt(2) * Random.nextInt(14)).scoreArray(),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input upperTotal() {
            return new Project2Input(
                    null,
                    null,
                    scores(Random.nextInt(2) * Random.nextInt(14)).scoreArray(),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input upperBonus() {
            return new Project2Input(
                    null,
                    null,
                    scores(Random.nextInt(2) * Random.nextInt(14)).scoreArray(),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input lowerTotal() {
            return new Project2Input(
                    null,
                    null,
                    scores(Random.nextInt(2) * Random.nextInt(14)).scoreArray(),
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);
        }

        public static Project2Input calculateUpperCategory() {
            int category = Random.nextInt(6);
            int[] dice = Random.coinflip() ? scorableDice(-1) : scorableDice(category);
            return new Project2Input(null, dice, null, null, null, null, category, null, null);
        }

        public static Project2Input calculateThreeOfAKind() {
            return lowerCategoryInput(6);
        }

        public static Project2Input calculateFourOfAKind() {
            return lowerCategoryInput(7);
        }

        public static Project2Input calculateFullHouse() {
            return lowerCategoryInput(8);
        }

        public static Project2Input calculateSmallStraight() {
            return lowerCategoryInput(9);
        }

        public static Project2Input calculateLargeStraight() {
            return lowerCategoryInput(10);
        }

        public static Project2Input calculateYahtzee() {
            return lowerCategoryInput(11);
        }

        public static Project2Input calculateChance() {
            return lowerCategoryInput(12);
        }

        private static Project2Input lowerCategoryInput(int category) {
            int[] dice = Random.coinflip() ? scorableDice(-1) : scorableDice(category);
            return new Project2Input(null, dice, null, null, null, null, null, null, null);
        }

        private static int[] scorableDice(int category) {
            if (category < 0) {
                category = Random.nextInt(13);
            }

            int[] dice = Random.dice(6, 5);

            // good dice for (some) categories half the time
            if (Random.coinflip()) {
                int die1, die2;
                switch (category) {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        // upper category
                        int count = Random.nextInt(2, dice.length);
                        for (int i = 0; i < count; ++i) {
                            dice[i] = category + 1;
                        }
                        break;
                    case 6:
                        // 3 of a kind
                        die1 = Random.die(6);
                        for (int i = 0; i < 3; ++i) {
                            dice[i] = die1;
                        }
                        break;
                    case 7:
                        // 4 of a kind
                        die1 = Random.die(6);
                        for (int i = 0; i < 4; ++i) {
                            dice[i] = die1;
                        }
                        break;
                    case 8:
                        // full house
                        die1 = Random.die(6);
                        die2 = Random.nextIntExcluding(1, 7, die1);
                        for (int i = 0; i < 3; ++i) {
                            dice[i] = die1;
                        }
                        for (int i = 3; i < dice.length; ++i) {
                            dice[i] = die2;
                        }
                        break;
                    case 11:
                        // yahtzee
                        die1 = Random.die(6);
                        for (int i = 0; i < dice.length; ++i) {
                            dice[i] = die1;
                        }
                        break;
                        // straights and chance can just be random
                }

                // shuffle so the adjusted dice aren't in a predictable order
                Random.shuffle(dice);
            }

            return dice;
        }

        private static record Scores(int[] scoreArray, boolean[] inUseArray) {}

        private static Scores scores(int freeCount) {
            int[] scoreArray =
                    new int[] {
                        Random.nextInt(6) * 1,
                        Random.nextInt(6) * 2,
                        Random.nextInt(6) * 3,
                        Random.nextInt(6) * 4,
                        Random.nextInt(6) * 5,
                        Random.nextInt(6) * 6,
                        Random.die(6) * 3 + Random.die(6) + Random.die(6),
                        Random.die(6) * 4 + Random.die(6),
                        Random.nextInt(2) * 25,
                        Random.nextInt(2) * 30,
                        Random.nextInt(2) * 40,
                        Random.nextInt(2) * 50,
                        Random.die(6)
                                + Random.die(6)
                                + Random.die(6)
                                + Random.die(6)
                                + Random.die(6),
                    };
            boolean[] inUseArray = new boolean[13];
            for (int i = 0; i < inUseArray.length; ++i) {
                inUseArray[i] = true;
            }

            int[] emptyOrder = IntStream.range(0, 13).toArray();
            Random.shuffle(emptyOrder);

            for (int i = 0; i < freeCount; ++i) {
                inUseArray[emptyOrder[i]] = false;
                scoreArray[emptyOrder[i]] = 0;
            }

            return new Scores(scoreArray, inUseArray);
        }

        private static String[] categoryNames() {
            return new String[] {
                "Aces",
                "Twos",
                "Threes",
                "Fours",
                "Fives",
                "Sixes",
                "Three of a Kind",
                "Four of a Kind",
                "Full House",
                "Small Straight",
                "Large Straight",
                "Yahtzee",
                "Chance"
            };
        }

        private static String gameScanner() {
            int[] categories = IntStream.range(1, 14).toArray();
            Random.shuffle(categories);
            String scanner = "";
            for (int c : categories) {
                scanner += rerollPhaseScanner() + "\n" + c + "\n";
            }
            return scanner;
        }

        private static String scorePhaseScanner(boolean[] inUseArray) {
            ArrayList<Integer> inUseIndices = new ArrayList<>(), freeIndices = new ArrayList<>();
            for (int i = 0; i < inUseArray.length; ++i) {
                if (inUseArray[i]) {
                    inUseIndices.add(i + 1);
                } else {
                    freeIndices.add(i + 1);
                }
            }

            int errors = Random.nextInt(2) * Random.nextInt(2) * Random.nextInt(1, 10);
            String[] commands = new String[errors + 1];
            commands[commands.length - 1] =
                    "" + freeIndices.get(Random.nextInt(freeIndices.size()));

            for (int i = 0; i < errors; ++i) {
                if (inUseIndices.isEmpty() || Random.coinflip()) {
                    commands[i] = "" + Random.nextInt(-100, 1, 14, 100);
                } else {
                    commands[i] = "" + inUseIndices.get(Random.nextInt(inUseIndices.size()));
                }
            }

            String scanner = Strings.joinDelimited("\n", commands);

            Logger.info(scanner);

            return scanner;
        }
    }
}
