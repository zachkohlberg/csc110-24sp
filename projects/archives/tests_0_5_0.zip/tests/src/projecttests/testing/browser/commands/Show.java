package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.LineStatus;
import projecttests.testing.TestCase;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.Strings;

import java.util.List;
import java.util.stream.Collectors;

/** View information about a specific test case. */
public class Show implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, CommandArgs args) throws TestingException {
        if (args.size() == 0) {
            throw new TestingException(id() + " expects one or more arguments");
        }

        TestCase result = null;
        try {
            int id = Integer.parseInt(args.get(0));
            result = context.getById(id);
        } catch (NumberFormatException e) {
            // nothing to do, exception will be thrown by following null check
        }

        if (result == null) {
            throw new TestingException(args.get(0) + " is not a valid id number.");
        }

        final TestCase finalResult = result;
        List<String> invalid =
                args.stream().skip(1).filter(i -> getInfo(finalResult, i) == null).toList();
        if (!invalid.isEmpty()) {
            throw new TestingException(
                    "ERROR: the option(s) " + Strings.join(invalid, ", ") + " are invalid.");
        }

        System.out.println(result.headerString());
        if (args.size() > 1) {
            System.out.println(
                    args.stream()
                            .skip(1)
                            .map(i -> getInfo(finalResult, i))
                            .collect(Collectors.joining("\n")));
        } else {
            System.out.println(result.fullInfo());
        }
    }

    private String getInfo(TestCase result, String info) {
        return switch (info) {
            case "in", "input" -> result.inputString();
            case "st", "student" -> result.studentOutputString();
            case "ex", "expected" -> result.expectedOutputString();
            case "out", "output" ->
                    result.studentOutputString() + "\n" + result.expectedOutputString();
            case "out-err" ->
                    result.studentOutputString(i -> i != LineStatus.MATCH)
                            + "\n"
                            + result.expectedOutputString(i -> i != LineStatus.MATCH);
            case "io" ->
                    result.inputString()
                            + "\n"
                            + result.studentOutputString()
                            + "\n"
                            + result.expectedOutputString();
            case "err", "error" -> result.errorsString();
            case "feedback" -> result.additionalFeedbackString();
            case "full" -> result.fullInfo();
            default -> null;
        };
    }

    @Override
    public String id() {
        return "show";
    }

    @Override
    public String help() {
        return """
Shows information about a specific test case. If no INFO is specified, then full
information about the test case will be shown.

USAGE: show ID [INFO]...

ID is the number after the test label.

INFO Options:
    in, input       the input given to your code
    st, student     your code's output
    ex, expected    the expected output
    out, output     both your code's output and the expected output
    out-err         only output lines listed as NO MATCH or ERROR
    io              both the input and output
    err, error      error messages
    feedback        additional feedback messages
    full            all available information (default)

Examples:

show 3
show 11 out
show 5 in st
show 5 io error
show 1 full
""";
    }
}
