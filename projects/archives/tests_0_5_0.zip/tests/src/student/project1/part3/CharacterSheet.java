package student.project1.part3;

/**
 * Placeholder for 1.3 so other test code can compile.
 */
public class CharacterSheet {
    public static void run(java.util.Scanner input) {}
}
