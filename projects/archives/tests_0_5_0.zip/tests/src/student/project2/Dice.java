package student.project2;

import java.util.Random;

/** Allows RNG seed to be set so number sequence is deterministic. */
public class Dice {
    private static Random r = new Random();

    public static void setSeed(long seed) {
        r.setSeed(seed);
    }

    public static int roll(int sides) {
        return r.nextInt(1, sides + 1);
    }

    public static int d4() {
        return roll(4);
    }

    public static int d6() {
        return roll(6);
    }

    public static int d8() {
        return roll(8);
    }

    public static int d10() {
        return roll(10);
    }

    public static int d12() {
        return roll(12);
    }

    public static int d20() {
        return roll(20);
    }
}
