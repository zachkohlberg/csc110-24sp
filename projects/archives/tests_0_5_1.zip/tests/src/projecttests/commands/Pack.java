package projecttests.commands;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.projects.Projects;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.FileIO;
import projecttests.util.Project;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/** Packages one or more projects for submission. */
public class Pack implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        if (args.size() != 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        Logger.info("pack command");

        boolean includeNopass = args.flagSet("include-nopass");

        List<Project> include =
                Projects.all().stream().filter(i -> check(i, includeNopass)).toList();

        if (include.isEmpty()) {
            Logger.info("No projects included, did not create zip.").print();
            return;
        }

        Path zipPath = Main.settings().projectsPath().resolve("guided_project_submission.zip");

        List<Path> contents =
                include.stream()
                        .flatMap(p -> p.projectFilePaths().stream().map(i -> i.normalize()))
                        .toList();

        try {
            Logger.info("Zipping project files.");
            FileIO.zip(zipPath, contents);
        } catch (IOException e) {
            throw new TestingException(
                    "IOException while trying to zip project files: " + e.getMessage(), e);
        }
    }

    boolean check(Project project, boolean includeNopass) {
        Logger.info("Checking project " + project.id()).print();
        String name = "Project " + project.id();

        if (!project.checkProjectFiles()) {
            Logger.info(
                            name
                                    + " will be skipped because it is missing files or a file is"
                                    + " named incorrectly.")
                    .print();
            return false;
        } else {
            Logger.info(name + "'s files were located successfully.").print();
        }

        List<String> passData = FileIO.loadOrElse(project.recordFilePath(), null);
        if (passData == null || passData.size() == 0 || !passData.get(0).equals("PASS")) {
            if (includeNopass) {
                Logger.info(
                                "WARNING: "
                                        + name
                                        + " hasn't passed its tests, but you've chosen to include"
                                        + " nonpassing projects.")
                        .print();
            } else {
                Logger.info(
                                name
                                        + " will be skipped because it hasn't passed its tests. You"
                                        + " can include it anyway by rerunning this command with"
                                        + " the --include-nopass flag.")
                        .print();
                return false;
            }
        } else {
            Logger.info(name + " appears to have passed its tests.");
        }

        Logger.info(name + " will be included in the zip.").print();

        return true;
    }

    @Override
    public String id() {
        return "pack";
    }

    @Override
    public String help() {
        return """
Packages all projects that have previously passed their tests for upload to
Blackboard.

USAGE: {COMMAND} pack [FLAG]...

Flags:
    --include-nopass
        Include projects that haven't passed their tests.
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
