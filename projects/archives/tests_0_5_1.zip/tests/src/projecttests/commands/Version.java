package projecttests.commands;

import projecttests.*;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.Strings;

/** Displays program version */
public class Version implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        if (args.size() > 0) {
            throw new TestingException(
                    id() + " expects zero arguments, not " + Strings.join(args.args(), ", "));
        }

        System.out.println(Main.VERSION);
    }

    @Override
    public String id() {
        return "version";
    }

    @Override
    public String help() {
        return """
Displays the program version.

USAGE:  {COMMAND} version
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
