package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JavaFunctionTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestCase;
import projecttests.testing.TestResult;
import projecttests.testing.input.Project2Input;
import projecttests.testing.input.generators.Project2;
import projecttests.util.Project;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/** Tests for project 2 part 1. */
public class Project2Part1 implements Project {
    @Override
    public String id() {
        return "2.1";
    }

    @Override
    public String programName() {
        return "DiceGame.java";
    }

    @Override
    public boolean compiles() {
        return true;
    }

    @Override
    public Path path() {
        return FileSystems.getDefault().getPath("project2", "part1");
    }

    @Override
    public TestResult test() throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this, List.of("System.exit"));
        preprocessor.run("student.project2.part1");

        ArrayList<TestCase> results = new ArrayList<>();

        int nextId = 1;
        JavaFunctionTest test;

        test = new JavaFunctionTest(this, "roll-all-dice", nextId, this::testRollAllDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "roll-some-dice", nextId, this::testRollSomeDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "dice-string", nextId, this::testDiceString);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "game", nextId, this::testGame);
        results.addAll(test.run());

        return new TestResult(Collections.unmodifiableList(results), preprocessor.studentCode());
    }

    @Override
    public void generateIO() throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this);
        preprocessor.run("student.project2.part1");

        JavaFunctionTest test;

        test = new JavaFunctionTest(this, "roll-all-dice", 1, this::testRollAllDice);
        test.generateData(Project2.generate(Project2.Part1::rollAllDice, 50));

        test = new JavaFunctionTest(this, "roll-some-dice", 1, this::testRollSomeDice);
        test.generateData(Project2.generate(Project2.Part1::rollSomeDice, 50));

        test = new JavaFunctionTest(this, "dice-string", 1, this::testDiceString);
        test.generateData(Project2.generate(Project2.Part1::diceString, 50));

        test = new JavaFunctionTest(this, "game", 1, this::testGame);
        test.generateData(Project2.generate(Project2.Part1::game, 10));
    }

    private List<String> testGame(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part1.DiceGame.game(new Scanner(input.userInputScanner()));
        return Collections.emptyList();
    }

    private List<String> testRollAllDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part1.DiceGame.rollAllDice(input.diceArray());
        return Collections.emptyList();
    }

    private List<String> testRollSomeDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part1.DiceGame.rollSomeDice(input.diceArray(), input.rerollLabels());
        return Collections.emptyList();
    }

    private List<String> testDiceString(Project2Input input) {
        String returnValue = student.project2.part1.DiceGame.diceString(input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }
}
