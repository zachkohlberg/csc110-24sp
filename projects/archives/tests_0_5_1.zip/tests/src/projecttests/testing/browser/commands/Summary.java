package projecttests.testing.browser.commands;

import projecttests.TestingException;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

/** Display summary of all test results */
public class Summary implements Command<ResultsBrowser> {
    @Override
    public void run(ResultsBrowser context, CommandArgs args) throws TestingException {
        if (args.size() > 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        System.out.println(context.summary());
    }

    @Override
    public String id() {
        return "summary";
    }

    @Override
    public String help() {
        return
        """
Displays a summary of all test results

USAGE: summary
""";
    }
}
