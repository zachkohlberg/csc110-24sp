package projecttests.util;

import projecttests.TestingException;

/** Defines interface for program's commands. */
public interface Command<T> extends HasId {
    void run(T context, CommandArgs args) throws TestingException;

    String help();
}
